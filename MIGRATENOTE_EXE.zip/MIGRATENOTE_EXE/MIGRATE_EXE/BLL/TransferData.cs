﻿using MIGRATE_EXE.DALService;
using MIGRATE_EXE.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MIGRATE_EXE.Utility;
using MIGRATE_EXE.log;
using System.Globalization;
using System.Data;

namespace MIGRATE_EXE.BLL
{
    class TransferData
    {
        public static bool Transfer(Criteria data)
        {
            CultureInfo ci = new CultureInfo("en-US");
            IBlockConfig bconf = ConfigFactory.GetConfig();
            bool complete = false;
            string strMsgDes = string.Empty;
            string strCsnNo = string.Empty;
            string strStartTime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            DALITaaS DAL_AS400 = new DALITaaS();
            complete = DAL_AS400.TransferData3(bconf.AS400SourceSelect, bconf.MSSQLDestinationTable, data, ref strMsgDes );
            if (!complete)
            {
                // Error;
                string heading = bconf.CubeName + " " + bconf.AS400_SYSTEM + " to " + bconf.NOTE_SYSTEM  + " Not Complete";
                Console.WriteLine(heading);

                // Create Log AS400
                string strPath = string.Empty;
                Logger.WriteTrace(false, 
                                    bconf.LogAS400Column , 
                                    0, 
                                    bconf.LogAS400File , 
                                    false, 
                                    ref strPath);
                if(strPath != "")
                {
                    if(!Program.pathAS400.Where(p=> p == strPath).Any())
                        Program.pathAS400.Add(strPath);
                }
                Logger.WriteTrace(false,DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", ci),0,bconf.LogAS400File,true,ref strPath);
                Logger.WriteTrace(false,"AS400", 0, bconf.LogAS400File,false,ref strPath);
                Logger.WriteTrace(false, "Error" ,0 ,  bconf.LogAS400File , false, ref strPath);
                if(!string.IsNullOrEmpty(strMsgDes))
                {
                    if(strMsgDes.IndexOf("|") > 0)
                    {
                        var splitDate = strMsgDes.Split('|');

                        Logger.WriteTrace(false, splitDate[1], 0  ,bconf.LogAS400File ,false , ref strPath);
                        Logger.WriteTrace(false, splitDate[0], 0 , bconf.LogAS400File , false , ref strPath);
                    }
                    else
                    {
                        Logger.WriteTrace(false, "" , 0 , bconf.LogAS400File , false , ref strPath);
                        Logger.WriteTrace(false, strMsgDes , 0,  bconf.LogAS400File , false , ref strPath);
                    }
                }


                MailStub.SendEmail(false,
                              bconf.EmailFrom,
                              bconf.EmailListReceive,
                              bconf.CubeName,
                              heading +
                              " : " +
                              DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"),
                              "\n\t" +
                              strMsgDes.Trim(),
                              Program.pathAS400);
            }
            else
            {
                // Success 
                Console.WriteLine(bconf.CubeName + " " + bconf.AS400_SYSTEM + " to "  + bconf.NOTE_SYSTEM + " Complete");
                string strEndTime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            }
        

            return complete;
        }

        public static bool ProcessDashBoard(Criteria data)
        {
            bool status = false;
            string strMsgDes = string.Empty;
            IBlockConfig bconf = ConfigFactory.GetConfig();
            string system = bconf.NOTE_SYSTEM;
            string _commandTimeout = bconf.CommandTimeout;
            int cmdTimeout = -1;
            if (!string.IsNullOrEmpty(_commandTimeout))
            {
                int.TryParse(_commandTimeout, out cmdTimeout);
            }
            DALBasic basic = new DALBasic();
            string dbType = basic.GetDataBase(system).ToUpper().Trim();
            _commandTimeout = bconf.CommandTimeout;
            cmdTimeout = -1;


            DALITaaS DALDashBoard = new DALITaaS(dbType, system, cmdTimeout);

            status = DALDashBoard.NoteProcess2(bconf.MSSQLDestinationTable, bconf.MSSQLTableNoteCondition, data,bconf.MSSQLStoreDashBoard,bconf.MSSQLUpdateFlagNote, ref strMsgDes);

            if (!status)
            {
                // Error;
                string heading = bconf.CubeName + " " + bconf.NOTE_SYSTEM + " Not Complete";
                Console.WriteLine(heading);

                string pathDetail = string.Empty;
                foreach (var p in Program.pathDetailMSSQL.Distinct())
                {
                    pathDetail += p + "\n\t";
                }

                string text = SummaryMigrate(data);

                MailStub.SendEmail(false,
                              bconf.EmailFrom,
                              bconf.EmailListReceive,
                              bconf.CubeName,
                              heading +
                              " : " +
                              DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"),
                              "\n\t" + text +
                              pathDetail,
                              Program.pathSumMSSQL);
            }
            else
            {
                // Success 
                Console.WriteLine(bconf.CubeName + " " + bconf.NOTE_SYSTEM + " Complete");
            }

            return status;
        }

        public static bool ClearData(Criteria data)
        {
            bool status = false;
            string strException = string.Empty;

            IBlockConfig bconf = ConfigFactory.GetConfig();
            string system = bconf.NOTE_SYSTEM;
            string _commandTimeout = bconf.CommandTimeout;
            int cmdTimeout = -1;
            if (!string.IsNullOrEmpty(_commandTimeout))
            {
                int.TryParse(_commandTimeout, out cmdTimeout);
            }
            DALBasic basic = new DALBasic();
            string dbType = basic.GetDataBase(system).ToUpper().Trim();
            _commandTimeout = bconf.CommandTimeout;
            cmdTimeout = -1;
            if (!string.IsNullOrEmpty(_commandTimeout))
            {
                int.TryParse(_commandTimeout, out cmdTimeout);
            }
            DALITaaS DALClear = new DALITaaS(dbType, system, cmdTimeout);

            Console.WriteLine(string.Format("==  Start Process {0}  ==",DateTime.Now));
            Console.WriteLine(string.Format("==> Count Row Note DashBoard & Note Analytics " +  "\n\t" + " : From {0} To {1}",data.start,data.end));

            List<Result> result = DALClear.SelectData(bconf.MSSQLSourceSelectNote, data);
            if(result.Count > 0)
            {
                foreach(var rs in result)
                {
                    Console.WriteLine(rs.text);

                    Program.recordSummary += "\n\t" + " Delete " + rs.name + "\t\t" + rs.value.ToString() + " Records.";
                }
                var checkSelect = result.Where(p => p.value > 0).Any();
                if(checkSelect)
                {
                    // มี Record 
                    Program.recordSummary += "\n\t Time : " + DateTime.Now.ToString("HH:mm:ss");
                    status = DALClear.ClearData(bconf.MSSQLSourceDeleteNote, data, ref strException);
                    Program.recordSummary += " - " + DateTime.Now.ToString("HH:mm:ss");
                    if(status)
                    {
                        Console.WriteLine("==> Delete Note DashBoard & Note Analytics Successful");
                    }
                    else
                    {
                        // Write Log Error
                        Console.WriteLine("==> Delete Note DashBoard & Note Analytics UnSuccessful");
                    }
                }
                else
                {
                    // ไม่มี Record ตามเงื่อนไข
                    Console.WriteLine(string.Format("==> Count 0 Row Note DashBoard & Note Analytics"));
                }
            }
            else
            {
                Console.WriteLine("==> Count 0 Row Note DashBoard & Note Analytics");
            }

            //Console.WriteLine(string.Format("==  End Process {0}  ==", DateTime.Now));

            return status;

        }

        public static string SummaryMigrate(Criteria data)
        {
            StringBuilder sb = new StringBuilder();
            Console.WriteLine("================================================");
            Console.WriteLine("==      Display Diff Data AS400 To MSSQL      ==");
            Console.WriteLine("================================================");
            Console.WriteLine(string.Format("==  Start Process {0} ==", DateTime.Now));

            IBlockConfig bconf = ConfigFactory.GetConfig();
            string strMsgAS400 = string.Empty;
            string strMsgMSSQL = string.Empty;
            List<Summary> result = new List<Summary>();
            bool checkDup = false;
            int countMS = 0;
            try
            {
                DALITaaS DAL = new DALITaaS();
                DataSet dsAS400 = DAL.SelectAS400ToDataSet(bconf.AS400SourceCount, data, ref strMsgAS400);
                DataSet dsMSSQL = DAL.SelectMSSQLToDataSet(bconf.MSSQLDestinationCount, data, ref strMsgMSSQL);
                DataSet dsFinal = new DataSet();
                foreach(DataRow drAS400 in dsAS400.Tables[0].Rows)
                {
                    checkDup = false;
                    foreach (DataRow drMSSQL in dsMSSQL.Tables[0].Rows)
                    {
                        countMS = Convert.ToInt32(drMSSQL[2]);
                        if (drAS400[0].ToString().Trim() == drMSSQL[0].ToString().Trim() && 
                            drAS400[1].ToString().Trim() == drMSSQL[1].ToString().Trim() && 
                            drAS400[2].ToString() == drMSSQL[2].ToString())
                        {
                            checkDup = true;
                            break;
                        }
                        else if (drAS400[0].ToString().Trim() == drMSSQL[0].ToString().Trim() && 
                            drAS400[1].ToString().Trim() == drMSSQL[1].ToString().Trim() && 
                            drAS400[2].ToString() != drMSSQL[2].ToString())
                        {
                            result.Add(new Summary()
                            {
                                actionCode = drAS400[0].ToString(),
                                resultCode = drAS400[1].ToString(),
                                countAS400 = Convert.ToInt32(drAS400[2]),
                                countMSSQL = Convert.ToInt32(drMSSQL[2]),
                                diffRow = Convert.ToInt32(drAS400[2]) - Convert.ToInt32(drMSSQL[2])
                            });
                            checkDup = true;
                            break;
                        }
                    }

                    if(checkDup == false)
                    {
                        result.Add(new Summary()
                        {
                            actionCode = drAS400[0].ToString(),
                            resultCode = drAS400[1].ToString(),
                            countAS400 = Convert.ToInt32(drAS400[2]),
                            countMSSQL = 0,
                            diffRow = Convert.ToInt32(drAS400[2])
                        });
                    }
                }

                
                if (result.Count > 0)
                {
                    sb.Append("<table style='border:1px solid;border-collapse:collapse;'><tr style='border:1px solid'><th style='border:1px solid'>ActionCode</th><th style='border:1px solid'>ResultCode</th><th style='border:1px solid'>Count AS400</th><th style='border:1px solid'>Count MSSQL</th><th style='border:1px solid'>Diff Row</th></tr>");
                    foreach (var item in result)
                    {
                        sb.Append("<tr style='border:1px solid'>");
                        sb.Append("<td style='border:1px solid'>" + item.actionCode + "</td>");
                        sb.Append("<td style='border:1px solid'>" + item.resultCode + "</td>");
                        sb.Append("<td style='border:1px solid'>" + item.countAS400 + "</td>");
                        sb.Append("<td style='border:1px solid'>" + item.countMSSQL + "</td>");
                        sb.Append("<td style='border:1px solid'>" + item.diffRow + "</td>");
                        sb.Append("</tr>");
                    }
                    sb.Append("</table>");
                }
                Console.WriteLine(string.Format("==  End Process {0} ==", DateTime.Now));

            }
            catch(Exception ex)
            {
                
            }

            return sb.ToString();
          
        }

        public static bool ClearDataSpecialNote(Criteria data)
        {
            bool status = false;
            string strException = string.Empty;

            IBlockConfig bconf = ConfigFactory.GetConfig();
            string system = bconf.NOTE_SYSTEM;
            string _commandTimeout = bconf.CommandTimeout;
            int cmdTimeout = -1;
            if (!string.IsNullOrEmpty(_commandTimeout))
            {
                int.TryParse(_commandTimeout, out cmdTimeout);
            }
            DALBasic basic = new DALBasic();
            string dbType = basic.GetDataBase(system).ToUpper().Trim();
            _commandTimeout = bconf.CommandTimeout;
            cmdTimeout = -1;
            if (!string.IsNullOrEmpty(_commandTimeout))
            {
                int.TryParse(_commandTimeout, out cmdTimeout);
            }
            DALITaaS DALClear = new DALITaaS(dbType, system, cmdTimeout);

            Console.WriteLine(string.Format("==  Start Process {0}  ==", DateTime.Now));
            Console.WriteLine(string.Format("==> Count Row CarfulList & Note Analytics " + "\n\t" + " : From {0} To {1}", data.start, data.end));

            List<Result> result = DALClear.SelectData(bconf.MSSQLSourceSelectSpecialNote, data);
            if (result.Count > 0)
            {
                foreach (var rs in result)
                {
                    Console.WriteLine(rs.text);

                    Program.recordSummary += "\n\t" + " Delete " + rs.name + "\t\t" + rs.value.ToString() + " Records.";
                }
                var checkSelect = result.Where(p => p.value > 0).Any();
                if (checkSelect)
                {
                    // มี Record 
                    Program.recordSummary += "\n\t Time : " + DateTime.Now.ToString("HH:mm:ss");
                    status = DALClear.ClearData(bconf.MSSQLSourceDeleteSpecialNote, data, ref strException);
                    Program.recordSummary += " - " + DateTime.Now.ToString("HH:mm:ss");
                    if (status)
                    {
                        Console.WriteLine("==> Delete CarfulList & Note Analytics Successful");
                    }
                    else
                    {
                        // Write Log Error
                        Console.WriteLine("==> Delete CarfulList & Note Analytics UnSuccessful");
                    }
                }
                else
                {
                    // ไม่มี Record ตามเงื่อนไข
                    Console.WriteLine(string.Format("==> Count 0 Row CarfulList & Note Analytics"));
                }
            }
            else
            {
                Console.WriteLine("==> Count 0 Row CarfulList & Note Analytics");
            }


            return status;
        }

        public static bool TransferSpecialNote(Criteria data)
        {
            CultureInfo ci = new CultureInfo("en-US");
            IBlockConfig bconf = ConfigFactory.GetConfig();
            bool complete = false;
            string strMsgDes = string.Empty;
            string strCsnNo = string.Empty;
            string strStartTime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            DALITaaS DAL_AS400 = new DALITaaS();
            complete = DAL_AS400.TransferDataSpecialNote(bconf.AS400SourceSelectSpecialNote, bconf.MSSQLDestinationTable, data, ref strMsgDes);
            if (!complete)
            {
                // Error;
                string heading = bconf.CubeName + " " + bconf.AS400_SYSTEM + " to " + bconf.NOTE_SYSTEM + " Not Complete";
                Console.WriteLine(heading);

                // Create Log AS400
                string strPath = string.Empty;
                Logger.WriteTrace(false,
                                    bconf.LogAS400Column,
                                    0,
                                    bconf.LogAS400File,
                                    false,
                                    ref strPath);
                if (strPath != "")
                {
                    if (!Program.pathAS400.Where(p => p == strPath).Any())
                        Program.pathAS400.Add(strPath);
                }
                Logger.WriteTrace(false, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", ci), 0, bconf.LogAS400File, true, ref strPath);
                Logger.WriteTrace(false, "AS400", 0, bconf.LogAS400File, false, ref strPath);
                Logger.WriteTrace(false, "Error", 0, bconf.LogAS400File, false, ref strPath);
                if (!string.IsNullOrEmpty(strMsgDes))
                {
                    if (strMsgDes.IndexOf("|") > 0)
                    {
                        var splitDate = strMsgDes.Split('|');

                        Logger.WriteTrace(false, splitDate[1], 0, bconf.LogAS400File, false, ref strPath);
                        Logger.WriteTrace(false, splitDate[0], 0, bconf.LogAS400File, false, ref strPath);
                    }
                    else
                    {
                        Logger.WriteTrace(false, "", 0, bconf.LogAS400File, false, ref strPath);
                        Logger.WriteTrace(false, strMsgDes, 0, bconf.LogAS400File, false, ref strPath);
                    }
                }


                MailStub.SendEmail(false,
                              bconf.EmailFrom,
                              bconf.EmailListReceive,
                              bconf.CubeName,
                              heading +
                              " : " +
                              DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"),
                              "\n\t" +
                              strMsgDes.Trim(),
                              Program.pathAS400);
            }
            else
            {
                // Success 
                Console.WriteLine(bconf.CubeName + " " + bconf.AS400_SYSTEM + " to " + bconf.NOTE_SYSTEM + " Complete");
                string strEndTime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            }


            return complete;
        }

        public static bool ProcessCarFul(Criteria data)
        {
            bool status = false;
            string strMsgDes = string.Empty;
            IBlockConfig bconf = ConfigFactory.GetConfig();
            string system = bconf.NOTE_SYSTEM;
            string _commandTimeout = bconf.CommandTimeout;
            int cmdTimeout = -1;
            if (!string.IsNullOrEmpty(_commandTimeout))
            {
                int.TryParse(_commandTimeout, out cmdTimeout);
            }
            DALBasic basic = new DALBasic();
            string dbType = basic.GetDataBase(system).ToUpper().Trim();
            _commandTimeout = bconf.CommandTimeout;
            cmdTimeout = -1;


            DALITaaS DAL = new DALITaaS(dbType, system, cmdTimeout);

            status = DAL.NoteProcess2(bconf.MSSQLDestinationTable, bconf.MSSQLTableSpecialNoteCondition, data, bconf.MSSQLStoreDashBoardCF, bconf.MSSQLUpdateFlagNote, ref strMsgDes);

            if (!status)
            {
                // Error;
                string heading = bconf.CubeName + " " + bconf.NOTE_SYSTEM + " Not Complete";
                Console.WriteLine(heading);

                string pathDetail = string.Empty;
                foreach (var p in Program.pathDetailMSSQL.Distinct())
                {
                    pathDetail += p + "\n\t";
                }

                string text = SummaryMigrateSpecialNote(data);

                MailStub.SendEmail(false,
                              bconf.EmailFrom,
                              bconf.EmailListReceive,
                              bconf.CubeName,
                              heading +
                              " : " +
                              DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"),
                              "\n\t" + text +
                              pathDetail,
                              Program.pathSumMSSQL);
            }
            else
            {
                // Success 
                Console.WriteLine(bconf.CubeName + " " + bconf.NOTE_SYSTEM + " Complete");
            }

            return status;
        }

        public static string SummaryMigrateSpecialNote(Criteria data)
        {
            StringBuilder sb = new StringBuilder();
            Console.WriteLine("================================================");
            Console.WriteLine("==      Display Diff Data AS400 To MSSQL      ==");
            Console.WriteLine("================================================");
            Console.WriteLine(string.Format("==  Start Process {0} ==", DateTime.Now));

            IBlockConfig bconf = ConfigFactory.GetConfig();
            string strMsgAS400 = string.Empty;
            string strMsgMSSQL = string.Empty;
            List<Summary> result = new List<Summary>();
            bool checkDup = false;
            int countMS = 0;
            try
            {
                DALITaaS DAL = new DALITaaS();
                DataSet dsAS400 = DAL.SelectAS400ToDataSetWhereCondition(bconf.AS400SourceCountSpecialNote, data, ref strMsgAS400);
                DataSet dsMSSQL = DAL.SelectMSSQLToDataSet(bconf.MSSQLDestinationCountSpecialNote , data, ref strMsgMSSQL);
                DataSet dsFinal = new DataSet();
                foreach (DataRow drAS400 in dsAS400.Tables[0].Rows)
                {
                    checkDup = false;
                    foreach (DataRow drMSSQL in dsMSSQL.Tables[0].Rows)
                    {
                        if (drAS400[0].ToString().Trim() == drMSSQL[0].ToString().Trim() &&
                            drAS400[1].ToString().Trim() == drMSSQL[1].ToString().Trim()
                          )
                        {
                            result.Add(new Summary()
                            {
                                actionCode = drAS400[0].ToString(),
                                resultCode = drAS400[1].ToString(),
                                countAS400 = Convert.ToInt32(drAS400[2]),
                                countMSSQL = Convert.ToInt32(drMSSQL[2]),
                                diffRow = Convert.ToInt32(drAS400[2]) - Convert.ToInt32(drMSSQL[2])
                            });
                            checkDup = true;
                            break;
                        }

                    }

                    if (checkDup == false)
                    {
                        result.Add(new Summary()
                        {
                            actionCode = drAS400[0].ToString(),
                            resultCode = drAS400[1].ToString(),
                            countAS400 = Convert.ToInt32(drAS400[2]),
                            countMSSQL = 0,
                            diffRow = Convert.ToInt32(drAS400[2])
                        });
                    }
                }


                if (result.Count > 0)
                {
                    sb.Append("<table style='border:1px solid;border-collapse:collapse;'><tr style='border:1px solid'><th style='border:1px solid'>ActionCode</th><th style='border:1px solid'>ResultCode</th><th style='border:1px solid'>Count AS400</th><th style='border:1px solid'>Count MSSQL</th><th style='border:1px solid'>Diff Row</th></tr>");
                    foreach (var item in result)
                    {
                        sb.Append("<tr style='border:1px solid'>");
                        sb.Append("<td style='border:1px solid'>" + item.actionCode + "</td>");
                        sb.Append("<td style='border:1px solid'>" + item.resultCode + "</td>");
                        sb.Append("<td style='border:1px solid'>" + item.countAS400 + "</td>");
                        sb.Append("<td style='border:1px solid'>" + item.countMSSQL + "</td>");
                        sb.Append("<td style='border:1px solid'>" + item.diffRow + "</td>");
                        sb.Append("</tr>");
                    }
                    sb.Append("</table>");
                }
                Console.WriteLine(string.Format("==  End Process {0} ==", DateTime.Now));

            }
            catch (Exception ex)
            {

            }

            return sb.ToString();

        }
    }
}
