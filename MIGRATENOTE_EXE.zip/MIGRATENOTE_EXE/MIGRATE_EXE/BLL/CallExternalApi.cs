﻿using MIGRATE_EXE.APIProvider;
using MIGRATE_EXE.APIProvider.Models;
using MIGRATE_EXE.Models;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.BLL
{
    public class CallExternalApi
    {
        public List<MicroServiceModel> microServices;
        private readonly MicroServiceModel tokenApi;
        private readonly MicroServiceModel allocateApi;

        public CallExternalApi()
        {
            microServices = JsonConvert.DeserializeObject<List<MicroServiceModel>>(ConfigurationSettings.AppSettings["ExternalApi"]);
            if(microServices != null)
            {
                allocateApi = microServices.GetMicroService("AllocateAPI");
                tokenApi = microServices.GetMicroService("TokenAPI");
            }
        }

        public class Login
        {
            public string UserName { get; set; }

            public string Password { get; set; }
        }

        public class Condition
        {
            public DateTime start { get; set; }
            public DateTime end { get; set; }
        }


        public string GetToken(string username , string password)
        {
            try
            {
                Login login = new Login();
                login.UserName = username;
                login.Password = password;

                var connect = new ConnectService(new APIProvider.ConnectService.ConnectServiceOptions
                {
                    url = string.Format("{0}/api/Token", tokenApi.host),
                    method = ConnectService.APIServiceMethod.POST,
                    data = JsonConvert.SerializeObject(login)
                });

                ResponseModel resgetToken = connect.connectAPI();
                if(resgetToken.success == false)
                {
                    throw new Exception(string.Format("Can't Generate Token because {0}",resgetToken.message));
                }
                else
                {
                    TokenModels token = APIProvider.Common.MapValue<TokenModels, object>(resgetToken.data);
                    return token.token;
                }
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public ResponseModel HealthCheck(string jwt)
        {
            try
            {
                Hashtable header = new Hashtable();
                header.Add("Authorization", string.Format("Bearer {0}", jwt));

                var connect = new ConnectService(new APIProvider.ConnectService.ConnectServiceOptions
                {
                    url = string.Format("{0}/api/HealthCheck", allocateApi.host),
                    header = header,
                    method = ConnectService.APIServiceMethod.GET
                });

                ResponseModel res = connect.connectAPI();
                if(res.success == false)
                {
                    return null;
                }
                else
                {
                    return APIProvider.Common.MapValue<ResponseModel, object>(res.data);
                }
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public ResponseModel RemoveNoteByCondition(string jwt, Criteria data)
        {
            try
            {
                Hashtable header = new Hashtable();
                header.Add("Authorization", string.Format("Bearer {0}", jwt));

                var connect = new ConnectService(new APIProvider.ConnectService.ConnectServiceOptions
                {
                    url = string.Format("{0}/api/DeleteNoteByCondition", allocateApi.host),
                    header = header,
                    method = ConnectService.APIServiceMethod.POST
                });

                ResponseModel res = connect.connectAPI();
                if (res.success == false)
                {
                    return null;
                }
                else
                {
                    return APIProvider.Common.MapValue<ResponseModel, object>(res.data);
                }
            }
            catch(Exception ex)
            {
                return null;
            }
        }
    }
}
