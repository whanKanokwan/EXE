﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.Models
{
    public class NoteModel
    {
        public string noteNumber { get; set; }

        public string csnNo { get; set; }

        public string contractNo { get; set; }

        public DateTime? noteDate { get; set; }

        public string actionCode { get; set; }

        public string personCode { get; set; }

        public string resultCode { get; set; }

        public string noteDescription { get; set; }

        public DateTime? ppDate { get; set; }

        public DateTime? pdDate { get; set; }

        public DateTime? recalDate { get; set; }

        public decimal ppAmt { get; set; }

        public decimal alreadyPaidAmt { get; set; }

        public string ppChannel { get; set; }

        public string callCenter { get; set; }

        public string telType { get; set; }

        public string telNo { get; set; }

        public string callType { get; set; }

        public string contactTo { get; set; }

        public string noteRemark { get; set; }

        public string noteFlag { get; set; }

        public string recordStatus { get; set; }

        public string noteBy { get; set; }

        public string noteByName { get; set; }

        public string refNoteNumber { get; set; }

        public DateTime? createDate { get; set; }

        public string createBy { get; set; }

        public DateTime? updateDate { get; set; }

        public string updateBy { get; set; }

    }
}
