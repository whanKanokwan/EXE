﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.Models
{
    public class Criteria
    {
        public string start { get; set; }

        public string end { get; set; }
    }

    public class Param
    {
        public string name { get; set; }
        public string value { get; set; }
    }

    public class Result
    {
        public string name { get; set; }
        public string text { get; set; }
        public int value { get; set; }
    }

    public class LogData
    {
        public string text { get; set; }

        public string startTime { get; set; }

        public string endTime { get; set; }
    }

    public class Summary
    {
        public string actionCode { get; set; }

        public string resultCode { get; set; }

        public int countAS400 { get; set; }

        public int countMSSQL { get; set; }

        public int diffRow { get; set; }
    }

    public class StoreProcedureList
    {
        public string spName { get; set; }

        public object parameters { get; set; }
    }

   
}
