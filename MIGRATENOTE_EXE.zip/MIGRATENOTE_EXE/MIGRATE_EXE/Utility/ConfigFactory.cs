﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.Utility
{

    internal interface IBlockConfig
    {
        string LogfilePath { get; }
        string AS400_SYSTEM { get; }
        string NOTE_SYSTEM { get; }

        string CommandTimeout { get; }

        string GetSQLFromList(string sTable);

        string ListTable { get; }

        //string FromSystemProcedureName { get; }

        //string FromSystemProcedureParam1 { get; }

        //string FromSystemProcedureParam2 { get; }

        string AS400SourceSelect { get; }

        //string AS400SourceParameter { get; }

        string MSSQLDestinationTable { get; }

        string MSSQLTableNoteCondition { get; }

        string MSSQLStoreDashBoard { get; }


        string MSSQLUpdateFlagNote { get; }

        string MSSQLSourceDeleteNote { get; }

        string CubeName { get; }

        string SMTPServer { get; }

        string MailHostName { get; }

        string EmailFrom { get; }

        string EmailErrorMsg { get; }

        string EmailSuccessMsg { get; }

        string EmailSendWhen { get; }

        string EmailListReceive { get; }

        string MSSQLSourceSelectNote { get; }

        string LogAS400Column { get; }

        string LogMSSQLSumColumn { get; }

        string LogAS400File { get; }

        string LogMssqlSumFile { get; }

        string LogMssqlDetailFile { get; }

        string LogMSSQLDetailColumn { get; }

        string AS400SourceCount { get; }

        string MSSQLDestinationCount { get; }

        string CommitRecord { get; }

        string UseMultiTask { get; }

        string MultiTaskQueueLength { get; }

        string SQLRecord { get; }

        string AS400SourceSelectSpecialNote { get; }

        string MSSQLSourceSelectSpecialNote { get; }

        string MSSQLSourceDeleteSpecialNote { get; }

        string MSSQLDestinationCountSpecialNote { get; }

        string MSSQLTableSpecialNoteCondition { get; }

        string MSSQLStoreDashBoardCF { get; }

        string AS400SourceCountSpecialNote { get; }
    }

    internal class ConfigFactory
    {

        public static IBlockConfig GetConfig()
        {
            return new Configuration();
        }
    }

    internal class Configuration : IBlockConfig
    {
        public string LogfilePath
        {
            get { return ConfigurationSettings.AppSettings["LOGFILE_PATH"]; }
        }

        public string AS400_SYSTEM
        {
            get { return ConfigurationSettings.AppSettings["AS400_SYSTEM"]; }
        }

        public string NOTE_SYSTEM
        {
            get { return ConfigurationSettings.AppSettings["NOTE_SYSTEM"]; }
        }

        public string CommandTimeout
        {
            get { return ConfigurationSettings.AppSettings["SYSTEM_COMMAND_TIMEOUT"]; }
        }

        public string GetSQLFromList(string sTable)
        {
            return (string)ConfigurationSettings.AppSettings["LISTTABLE_" + sTable];
        }

        public string ListTable
        {
            get { return ConfigurationSettings.AppSettings["LISTTABLE"]; } 
        }

        //public string FromSystemProcedureName
        //{
        //    get { return ConfigurationSettings.AppSettings["FROM_SYSTEM_PROCEDURE"];  }
        //}

        //public string FromSystemProcedureParam1
        //{
        //    get { return (string)ConfigurationSettings.AppSettings["FROM_SYSTEM_PROCEDURE_PARM1"]; }
        //}

        //public string FromSystemProcedureParam2
        //{
        //    get { return (string)ConfigurationSettings.AppSettings["FROM_SYSTEM_PROCEDURE_PARM2"]; }
        //}

        public string AS400SourceSelect
        {
            get { return (string)ConfigurationSettings.AppSettings["AS400_SOURCE_SELECT"]; }
        }

        //public string AS400SourceParameter
        //{
        //    get { return (string)ConfigurationSettings.AppSettings["AS400_SOURCE_PARAMETER"]; }
        //}

        public string MSSQLDestinationTable
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_DESTINATION_TABLE"]; }
        }

        public string MSSQLTableNoteCondition
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_TABLE_NOTE_CONDITION"]; }
        }
        
        public string MSSQLStoreDashBoard
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_STORE_DASHBOARD"]; }
        }

        public string MSSQLUpdateFlagNote
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_UPDATE_FLAG_NOTE"]; }
        }

        public string MSSQLSourceDeleteNote
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_SOURCE_DELETE_NOTE"]; }
        }

        public string CubeName
        {
            get { return (string)ConfigurationSettings.AppSettings["CubeName"]; }
        }

        public string SMTPServer
        {
            get { return (string)ConfigurationSettings.AppSettings["SMTP_SERVER"]; }
        }

        public string MailHostName
        {
            get { return (string)ConfigurationSettings.AppSettings["MailHostName"]; }
        }

        public string EmailFrom
        {
            get { return (string)ConfigurationSettings.AppSettings["EmailFrom"]; }
        }

        public string EmailErrorMsg
        {
            get { return (string)ConfigurationSettings.AppSettings["EmailErrorMsg"]; }
        }

        public string EmailSuccessMsg
        {
            get { return (string)ConfigurationSettings.AppSettings["EmailSuccessMsg"]; }
        }

        public string EmailSendWhen
        {
            get { return (string)ConfigurationSettings.AppSettings["EmailSendWhen"]; }
        }

        public string EmailListReceive
        {
            get { return (string)ConfigurationSettings.AppSettings["EmailListReceive"]; }
        }

        public string MSSQLSourceSelectNote
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_SOURCE_SELECT_NOTE"]; }
        }

        public string LogAS400Column
        {
            get { return (string)ConfigurationSettings.AppSettings["LogAS400Column"]; }
        }

        public string LogMSSQLSumColumn
        {
            get { return (string)ConfigurationSettings.AppSettings["LogMSSQLSumColumn"]; }
        }

        public string LogMSSQLDetailColumn
        {
            get { return (string)ConfigurationSettings.AppSettings["LogMSSQLDetailColumn"]; }
        }

        public string LogAS400File
        {
            get { return (string)ConfigurationSettings.AppSettings["LogAS400File"]; }
        }

        public string LogMssqlSumFile
        {
            get { return (string)ConfigurationSettings.AppSettings["LogMssqlSumFile"]; }
        }

        public string LogMssqlDetailFile
        {
            get { return (string)ConfigurationSettings.AppSettings["LogMssqlDetailFile"]; }
        }

        public string AS400SourceCount
        {
            get { return (string)ConfigurationSettings.AppSettings["AS400_SOURCE_COUNT"]; }
        }

        public string MSSQLDestinationCount
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_DESTINATION_COUNT"]; }
        }

        public string CommitRecord
        {
            get { return (string)ConfigurationSettings.AppSettings["COMMIT_RECORD"]; }
        }

        public string UseMultiTask
        {
            get { return (string)ConfigurationSettings.AppSettings["USE_MULTITASK"]; }
        }

        public string MultiTaskQueueLength
        {
            get { return (string)ConfigurationSettings.AppSettings["MULTITASK_QUEUE_LENGTH"]; }
        }

        public string SQLRecord
        {
            get { return (string)ConfigurationSettings.AppSettings["SQL_RECORD"]; }
        }

        public string AS400SourceSelectSpecialNote
        {
            get { return (string)ConfigurationSettings.AppSettings["AS400_SOURCE_SELECT_SPECIAL_NOTE"]; }
        }

        public string MSSQLSourceSelectSpecialNote
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_SOURCE_SELECT_SPECIAL_NOTE"]; }
        }

        public string MSSQLSourceDeleteSpecialNote
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_SOURCE_DELETE_SPECIAL_NOTE"]; }
        }

        public string MSSQLDestinationCountSpecialNote
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_DESTINATION_COUNT_SPECIAL_NOTE"]; }
        }

        public string MSSQLTableSpecialNoteCondition
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_TABLE_SPECIAL_NOTE_CONDITION"]; }
        }

        public string MSSQLStoreDashBoardCF
        {
            get { return (string)ConfigurationSettings.AppSettings["MSSQL_STORE_DASHBOARD_CF"]; }
        }

        public string AS400SourceCountSpecialNote
        {
            get { return (string)ConfigurationSettings.AppSettings["AS400_SOURCE_COUNT_SPECIAL_NOTE"]; }
        }
    }

}
