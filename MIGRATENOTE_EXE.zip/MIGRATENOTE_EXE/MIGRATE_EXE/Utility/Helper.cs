﻿using MIGRATE_EXE.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.Utility
{
    public static class Helper
    {
        public static List<T> DataTableToList<T>(this DataTable table) where T : class, new()
        {
            try
            {
                List<T> list = new List<T>();

                foreach (var row in table.AsEnumerable())
                {
                    T obj = new T();

                    foreach (var prop in obj.GetType().GetProperties())
                    {
                        try
                        {
                            PropertyInfo propertyInfo = obj.GetType().GetProperty(prop.Name);
                            propertyInfo.SetValue(obj, Convert.ChangeType(row[prop.Name], propertyInfo.PropertyType), null);
                        }
                        catch
                        {
                            continue;
                        }
                    }

                    list.Add(obj);
                }

                return list;
            }
            catch
            {
                return null;
            }
        }

     
        public static Criteria FormatDate(string startDate, string endDate)
        {
            CultureInfo en = new CultureInfo("en-US");
            String format = "yyyyMMdd HH:mm:ss";
           
            DateTime start = DateTime.ParseExact(startDate, "dd/MM/yyyy", en);
            DateTime startT = new DateTime(start.Year, start.Month, start.Day, 0, 0, 0);
            DateTime end =  DateTime.ParseExact(endDate, "dd/MM/yyyy",en);
            DateTime endT = new DateTime(end.Year, end.Month, end.Day, 23, 59, 59);

            Criteria ct = new Criteria();
            ct.start = startT.ToString(format, en);
            ct.end = endT.ToString(format, en);

            return ct;
        }
    }
}
