﻿using MIGRATE_EXE.log;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MIGRATE_EXE.Utility
{
    public class MailStub
    {
        public MailStub()
        {

        }

        private static bool IsEmail(string email)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                            @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                            @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            Regex re = new Regex(strRegex);
            if(re.IsMatch(email))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool SendEmail (bool isSuccess,string from ,string to , string cubeName , string reasonMsg , string bodyMsg , List<string> files = null)
        {
            bool status = false;
            string strFrom = from.ToString().Trim();
            string strSubject = "";
            string strBody = "";
            string strTo = to.ToString().Trim();
            string strCubeName = cubeName.ToString().Trim();
            string strReasonMsg = reasonMsg.ToString().Trim();

            string strSpace = " ";
            string strAsOf = "";

            try
            {
                IBlockConfig bconf = ConfigFactory.GetConfig();
                string strDateLog = DateTime.Today.ToString("dd/MM/yyyy");
                if (isSuccess == true)
                {
                    strSubject = bconf.EmailSuccessMsg +
                                    strSpace +
                                    strCubeName +
                                    strAsOf +
                                    strSpace +
                                    strReasonMsg;
                    strBody = bconf.EmailSuccessMsg +
                                    strSpace +
                                    strCubeName +
                                    strAsOf +
                                    strSpace +
                                    strReasonMsg +
                                    "\n\t" +
                                    bodyMsg.Trim();
                }
                else
                {
                    strSubject = bconf.EmailErrorMsg +
                                    strSpace +
                                    strCubeName +
                                    strAsOf +
                                    strSpace +
                                    strReasonMsg;
                    strBody = bconf.EmailErrorMsg +
                                    strSpace +
                                    strCubeName +
                                    strAsOf +
                                    strSpace +
                                    strReasonMsg +
                                    "\n\t" +
                                    bodyMsg.Trim();
                }

                MailMessage mailMsg = new MailMessage();
                mailMsg.From = (new MailAddress(strFrom));
                mailMsg.IsBodyHtml = true;
                mailMsg.Subject = strSubject;
                strBody = strBody.Replace("\n", "<BR>");
                strBody = strBody.Replace("\\n", "<BR>");
                mailMsg.Body = strBody;

                if(files != null)
                {
                    foreach(var file in files)
                    {
                        // Create  the file attachment for this email message.
                        Attachment data = new Attachment(file, MediaTypeNames.Application.Octet);
                        // Add time stamp information for the file.
                        ContentDisposition disposition = data.ContentDisposition;
                        disposition.CreationDate = System.IO.File.GetCreationTime(file);
                        disposition.ModificationDate = System.IO.File.GetLastWriteTime(file);
                        disposition.ReadDate = System.IO.File.GetLastAccessTime(file);
                        // Add the file attachment to this email message.
                        mailMsg.Attachments.Add(data);
                    }
                 
                }
              

                if (strTo.Length > 0 && strTo != null)
                {
                    string[] arTo = strTo.Split(';');
                    foreach(string str in arTo)
                    {
                        if(str.Trim().Length > 0)
                        {
                            if(IsEmail(str.Trim()))
                            {
                                mailMsg.To.Add(new MailAddress(str));
                            }
                            else
                            {
                                Console.WriteLine(str.Trim() + " Invalid E-mail format");
                                return false;
                            }
                              
                        }
                    }
                }

                mailMsg.Priority = MailPriority.High;
                SmtpClient smtpMail = new SmtpClient();
                smtpMail.Host = bconf.MailHostName;
                smtpMail.Port = 25;
                smtpMail.Send(mailMsg);
                status = true;
            }
            catch(Exception ex)
            {
                Logger.ErrorRoutine(true, ex);
            }

            return status;
        }

    }
}
