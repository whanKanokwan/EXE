﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.APIProvider.Models
{
    public class MicroServiceModel
    {
        public string name { get; set; }

        public string host { get; set; }
    }

    public static class MicroServicesExtension
    {
        public static MicroServiceModel GetMicroService(this List<MicroServiceModel> msData , string name)
        {
            try
            {
                return (from x in msData
                        where x.name.Equals(name)
                        select x).FirstOrDefault<MicroServiceModel>();
            }
            catch(Exception ex)
            {
                return null;
            }
        }
    }
}
