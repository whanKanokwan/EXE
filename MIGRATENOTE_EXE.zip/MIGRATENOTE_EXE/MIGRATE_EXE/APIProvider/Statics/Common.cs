﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.APIProvider
{
    public static class Common
    {
        static public T MapValue<T,C>(C model)
        {
            try
            {
                JsonSerializerSettings settings = new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    MissingMemberHandling = MissingMemberHandling.Ignore,
                    Formatting = Formatting.None,
                    DateFormatHandling = DateFormatHandling.IsoDateFormat
                };
                string json = JsonConvert.SerializeObject(model, settings);
                return JsonConvert.DeserializeObject<T>(json);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
