﻿using MIGRATE_EXE.APIProvider.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.APIProvider
{
  

    public class ConnectService
    {

        public enum APIServiceMethod
        {
            GET = 0,
            POST = 1,
            PUT = 2,
            DELETE = 3
        }

        public class ConnectServiceOptions
        {
            public string url { get; set; }

            public object data { get; set; }

            public int timeout { get; set; }

            public APIServiceMethod method { get; set; }

            public Hashtable header { get; set; }
        }

        private readonly int _timeout;
        private readonly string _url;
        private readonly object _data;
        public APIServiceMethod _method;
        private readonly Hashtable _header;

        public ConnectService(ConnectServiceOptions opts)
        {
            this._url = opts.url;
            this._header = opts.header;
            this._method = opts.method;
            this._data = opts.data;
            this._timeout = opts.timeout;
        }

        public ResponseModel connectAPI()
        {
            ResponseModel responseModel = new ResponseModel();

            var httpWebRequest = HttpWebRequest.Create(this._url);

            if(_timeout > 0)
            {
                httpWebRequest.Timeout = _timeout;
            }

            if(this._method != null)
            {
                httpWebRequest.Method = this._method.ToString();
            }

            httpWebRequest.ContentType = "application/json";

            if(this._header != null)
            {
                foreach(DictionaryEntry hash in this._header)
                {
                    httpWebRequest.Headers[hash.Key.ToString()] = hash.Value.ToString();
                }
            }

            if(this._method != APIServiceMethod.GET)
            {
                using (var streamWrite = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    streamWrite.Write(this._data);
                }
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                responseModel = JObject.Parse(streamReader.ReadToEnd()).ToObject<ResponseModel>();
            }

            return responseModel;
        }
    }
}
