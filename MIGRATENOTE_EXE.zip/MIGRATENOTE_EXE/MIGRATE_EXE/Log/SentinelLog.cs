﻿using MIGRATE_EXE.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.log
{
    internal class Logger
    {
        protected static string strLogFilePath = string.Empty;
        private static StreamWriter sw = null;
        protected static string _time = DateTime.Now.ToString("HHmmss");
        protected static bool bLoggingEnabled = false;

        public static string LogFilePath
        {
            set
            {
                strLogFilePath = value;
            }
            get
            {
                return strLogFilePath;
            }
        }

        private static string GetLogFilePath(bool exception = false ,int count = 0,string fileName = "")
        {
            try
            {
                IBlockConfig conf = ConfigFactory.GetConfig();
                string baseDir = conf.LogfilePath;
                string retFilePath;

                CultureInfo ci = new CultureInfo("en-US");
                if(exception)
                {
                    retFilePath = string.Format("{0}\\{1}_{2}_exception.csv", baseDir, DateTime.Today.ToString("yyyyMMdd", ci), _time);
                }
                else if (count == 0 && fileName == "")
                {
                    retFilePath = string.Format("{0}\\{1}_{2}.csv", baseDir, DateTime.Today.ToString("yyyyMMdd", ci), _time);
                }
                else if (count == 0 && fileName != "")
                {
                    retFilePath = string.Format("{0}\\{1}_{2}_{3}.csv", baseDir, DateTime.Today.ToString("yyyyMMdd", ci), _time, fileName);
                }
                else
                {
                    retFilePath = string.Format("{0}\\{1}_{2}-{3}.csv", baseDir,DateTime.Today.ToString("yyyyMMdd",ci),_time,count);
                }
                ci = null;

                if(File.Exists(retFilePath) == true)
                {
                    return retFilePath;
                }
                else
                {
                    if(!CheckDirectory(retFilePath))
                    {
                        return string.Empty;
                    }

                    FileStream fs = new FileStream(retFilePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                    fs.Close();
                    fs = null;
                }

                return retFilePath;
            }
            catch(Exception ex)
            {
                return string.Empty;
            }
        }

        private static bool CheckDirectory(string strLogPath)
        {
            try
            {
                int nFindSlashPos = strLogPath.Trim().LastIndexOf("\\");
                string strDirectoryName = strLogPath.Trim().Substring(0, nFindSlashPos);

                if(!Directory.Exists(strDirectoryName))
                {
                    Directory.CreateDirectory(strDirectoryName);
                }

                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }

        private static bool CustomErrorRoutine(Exception objException,string query = null)
        {
            string strPathName = string.Empty;
            CultureInfo ci = new CultureInfo("en-US");
            string strToDayFileName = string.Format("\\Log\\{0}Log.csv", DateTime.Today.ToString("yyyyMMdd", ci));
            ci = null;
            if(strLogFilePath.Equals(string.Empty))
            {
                string time = DateTime.Now.ToString("HHmm");
                bool exception = true;
                strPathName = GetLogFilePath(exception);
            }
            else
            {
                strPathName = (strLogFilePath.EndsWith(@"\") || strLogFilePath.EndsWith(@"/")) ?
                    strLogFilePath + strToDayFileName : strLogFilePath + "\\" + strToDayFileName;

                if(!File.Exists(strPathName))
                {
                    if (!CheckDirectory(strPathName))
                    {
                        return false;
                    }

                    FileStream fs = new FileStream(strPathName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                    fs.Close();
                    fs = null;
                }
            }

            bool bReturn = true;

            if(!WriteErrorLog(strPathName,objException,query))
            {
                bReturn = false;
            }

            return bReturn;
        }

        private static bool CustomErrorRoutine(string strMessage,int count ,string fileName ,bool newRecord , ref string refPathName)
        {
            string strPathName = string.Empty;
            CultureInfo ci = new CultureInfo("en-US");
            string strToDayFileName = string.Format("Ftp{0}.csv", DateTime.Today.ToString("yyyyMMdd", ci));
            ci = null;
            if(strLogFilePath.Equals(string.Empty))
            {
                string time = DateTime.Now.ToString("HHmm");
                strPathName = GetLogFilePath(count: count,fileName : fileName);
            }
            else
            {
                strPathName = (strLogFilePath.EndsWith(@"\") || strLogFilePath.EndsWith(@"/")) ?
                    strLogFilePath + strToDayFileName : strLogFilePath + "\\" + strToDayFileName;

                if(!File.Exists(strPathName))
                {

                    if(!CheckDirectory(strPathName))
                    {
                        return false;
                    }

                    FileStream fs = new FileStream(strPathName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                    fs.Close();
                    fs.Dispose();
                    fs = null;
                }
            }

            bool bReturn = true;

            refPathName = strPathName;


            if (!WriteLog(strPathName, strMessage,newRecord))
            {
                bReturn = false;
            }
                       
            return bReturn;
        }

        private static bool WriteLog(string strPathName,string strMessage, bool newRecord = false)
        {
            bool bReturn = false;
            string strException = string.Empty;
            try
            {
                sw = new StreamWriter(strPathName, true);
                CultureInfo ci = new CultureInfo("en-US");
                if(newRecord)
                {
                    sw.WriteLine();
                }
                sw.Write("{0},", strMessage);
                
                //sw.WriteLine("{0},{1}", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", ci), strMessage);
                sw.Flush();
                sw.Close();
                sw.Dispose();
                sw = null;
                bReturn = true;
            }
            catch(Exception ex)
            {
                bReturn = false;
            }
            return bReturn;
        }

        private static bool WriteErrorLog(string strPathName,Exception objException,string query = null)
        {
            bool bReturn = false;
            string strException = string.Empty;
            try
            {
                sw = new StreamWriter(strPathName, true);
                sw.WriteLine("------------- RunTime Error -----------------");
                sw.WriteLine("Source    :   " + objException.Source.ToString());
                sw.WriteLine("Method    :   " + objException.TargetSite.ToString());
                sw.WriteLine("Date      :   " + DateTime.Now.ToShortDateString());
                sw.WriteLine("Time      :   " + DateTime.Now.ToLongTimeString());
                sw.WriteLine("Computer  :   " + Dns.GetHostName().ToString());
                sw.WriteLine("Error     :   " + objException.Message.ToString().Trim());
                sw.WriteLine("Stack Trace   :   " + objException.StackTrace.ToString().Trim());
                sw.WriteLine("Query Detail  :   " + query);
                sw.WriteLine("------------- RunTime Error -----------------");
                sw.Flush();
                sw.Close();
                sw = null;
                bReturn = true;
            }
            catch(Exception ex)
            {
                bReturn = false;
            }

            return bReturn;
        }

        // public static bool WriteTrace(bool bLogType,string strMessage , int count = 0,string fileName = "",bool newRecord = false , ref string refPathName)
        public static bool WriteTrace(bool bLogType, string strMessage, int count, string fileName, bool newRecord, ref string refPathName)
        {
            bool bRet = true;
            try
            {
                if(bLogType)
                {
                    string EventLogName = "Error";
                    if(!EventLog.SourceExists(EventLogName))
                    {
                        EventLog.CreateEventSource(strMessage, EventLogName);
                    }
                    // Insert into event log
                    EventLog log = new EventLog();
                    log.Source = EventLogName;
                    log.WriteEntry(strMessage, EventLogEntryType.Error);
                    log = null;
                }
                else
                {
                    if(bLoggingEnabled)
                    {
                        bRet = false;
                    }
                    if(!CustomErrorRoutine(strMessage, count, fileName,newRecord,ref refPathName))
                    {
                        bRet = false;
                    }
                }
            }
            catch(Exception ex)
            {
                bRet = false;
            }

            return bRet;
        }

        public static bool ErrorRoutine(bool bLogType,Exception objException , string query = null)
        {
            try
            {
                if(bLogType)
                {
                    string eventLogName = "ErrorSample";
                    if(!EventLog.SourceExists(eventLogName))
                    {
                        EventLog.CreateEventSource(objException.Message, eventLogName);
                    }

                    EventLog log = new EventLog();
                    log.Source = eventLogName;
                    log.WriteEntry(objException.Message, EventLogEntryType.Error);
                    log = null;
                }
                else
                {
                    if(!CustomErrorRoutine(objException,query))
                    {
                        return false;
                    }
                }

                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }
    }
}
