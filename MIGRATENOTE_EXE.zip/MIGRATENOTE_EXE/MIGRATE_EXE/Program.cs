﻿using MIGRATE_EXE.BLL;
using MIGRATE_EXE.DALService;
using MIGRATE_EXE.log;
using MIGRATE_EXE.Models;
using MIGRATE_EXE.Utility;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE
{
    class Program
    {

        public static string migrate = "";
        public static List<string> pathAS400 = new List<string>();
        public static List<string> pathSumMSSQL = new List<string>();
        public static List<string> pathDetailMSSQL = new List<string>();

        public static bool isCreateLogDetail = false;
        public static bool isCreateLogSummary = false;

        private static string strStartTimeMain = "";
        private static string strEndTimeMain = "";

        public static string recordSummary = "";
        public static string selectFunc = "";

        static void Main(string[] args)
        {
            // Fix For Test
            args = new String[4];
            args[0] = "1";
            args[1] = "F0";
            args[2] = "01/06/2020";
            args[3] = "01/06/2020";


            Console.Clear();
            Console.WriteLine("===============================================");
            Console.WriteLine("===============================================");
            Console.WriteLine("==                                           ==");
            Console.WriteLine("==                Welecom To EXE             ==");
            Console.WriteLine("==                                           ==");
            Console.WriteLine("===============================================");

            //
            // Parameter 1 : Menu (1 : Migrate Note , 2 : Migrate Note Special , 3 : Sync)
            // Parmaeter 2 : (F0 run all step , F1 run step one , F2 run step two , F3 run step three
            // Parameter 2 : StartDate
            // Parameter 3 : EndDate
            //
            #region 
            if (args.Length != 4)
            {
                Console.WriteLine("Paramter invalid program require 4 parameter !!");
            }
            else
            {
                bool checkParameter = false;
                string func = "";
                string menuText = "";
                string startDate = string.Empty;
                string endDate = string.Empty;
                StringBuilder errorMessage = new StringBuilder();
                for (int i = 0; i < args.Length; i++)
                {
                    string argument = args[i];

                    if (i == 0)
                    {
                        if (argument == "1" || argument == "2" || argument == "3")
                        {
                            checkParameter = true;
                            func = argument;
                            if(argument == "1")
                            {
                                menuText = "Note";
                            }
                            else if (argument == "2")
                            {
                                menuText = "Note Special";
                            }
                            else if (argument == "3")
                            {
                                menuText = "Sync";
                            }
                        }
                        else
                        {
                            checkParameter = false;
                            errorMessage.Append("Function is not found \n Please select menu 1 | 2 | 3");
                        }
                    }

                    if (i == 1)
                    {
                        if (argument.ToUpper() == "F0" || argument.ToUpper() == "F1" || argument.ToUpper() == "F2" || argument.ToUpper() == "F3")
                        {
                            checkParameter = true;
                            func += argument.ToUpper();
                        }
                        else
                        {
                            checkParameter = false;
                            errorMessage.Append("Function is not found \n Please select function F0 | F1 | F2 | F3 ");
                        }
                    }

                    if (i == 2)
                    {
                        if (ValidateFormatDate(argument, "dd/MM/yyyy"))
                        {
                            checkParameter = true;
                            startDate = argument;
                        }
                        else
                        {
                            checkParameter = false;
                            errorMessage.Append("Input startDate invalid \n");
                        }
                    }

                    if (i == 3)
                    {
                        if (ValidateFormatDate(argument, "dd/MM/yyyy"))
                        {
                            checkParameter = true;
                            endDate = argument;
                        }
                        else
                        {
                            checkParameter = false;
                            errorMessage.Append("Input endDate invalid \n");
                        }
                    }

                }

                if (checkParameter == false)
                {
                    Console.WriteLine(errorMessage);
                }
                else
                {
                    Console.WriteLine("===============================================");
                    Console.WriteLine(string.Format("           Start Migrate {0}         ", menuText));
                    Console.WriteLine("===============================================");
                    Console.WriteLine(string.Format("Note Date From : {0}", startDate));
                    Console.WriteLine(string.Format("Note Date To : {0}", endDate));
                    strStartTimeMain = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");

                    selectFunc = func;
                    switch (func)
                    {
                        case "1F0":
                            // Run Migrate Note All Step  1 - 3
                            MigrateNote(Helper.FormatDate(startDate, endDate));
                            break;
                        case "1F1":
                            // Run Migrate Note Step 1
                            MigrateNoteStep1(Helper.FormatDate(startDate, endDate));
                            break;
                        case "1F2":
                            // Run Migrate Note Step 2
                            MigrateNoteStep2(Helper.FormatDate(startDate, endDate));
                            break;
                        case "1F3":
                            // Run Migrate Note Step 3
                            MigrateNoteStep3(Helper.FormatDate(startDate, endDate));
                            break;
                        case "2F0":
                            // Run Migrate Special Note All Step  1 - 3
                            MigrateSpecialNote(Helper.FormatDate(startDate, endDate));
                            break;
                        case "2F1":
                            // Run Migrate Special Note Step 1
                            MigrateNoteSpecialStep1(Helper.FormatDate(startDate, endDate));
                            break;
                        case "2F2":
                            // Run Migrate Special Note Step 2
                            MigrateNoteSpecialStep2(Helper.FormatDate(startDate, endDate));
                            break;
                        case "2F3":
                            // Run Migrate Special Note Step 3
                            MigrateNoteSpecialStep3(Helper.FormatDate(startDate, endDate));
                            break;
                        case "3":
                            Sync(); break;
                        default:
                            Console.Clear();
                            break;
                    }
                }
            }
            #endregion

            //MigrateNote(Helper.FormatDate("01/01/2020", "01/05/2020"));
            Console.WriteLine("===============================================");
            Console.WriteLine("==                                           ==");
            Console.WriteLine("==                 End Program               ==");
            Console.WriteLine("==                                           ==");
            Console.WriteLine("===============================================");
            Console.ReadLine();
        }

        private static void MigrateNoteStep1 (Criteria param)
        {
            IBlockConfig blockConfig = ConfigFactory.GetConfig();
            Console.WriteLine("===============================================");
            Console.WriteLine("==       Step 1 : Clear Data MSSQL           ==");
            Console.WriteLine("===============================================");
            Console.WriteLine(string.Format("== Start Process {0} ==", DateTime.Now));
            string strStartTime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            bool status = TransferData.ClearData(param);
            Console.WriteLine(string.Format("== End Process {0}  ==", DateTime.Now));
            if (selectFunc == "1F1")
            {
                strEndTimeMain = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
                MailStub.SendEmail(status == true ? true : false,
                             blockConfig.EmailFrom,
                             blockConfig.EmailListReceive,
                             blockConfig.CubeName,
                             "To " + blockConfig.NOTE_SYSTEM,
                             string.Format(" From : {0} - To : {1} ", param.start, param.end) + "\n\t Step 1 " + Program.recordSummary + "\n\tStart : " + strStartTime + " Finish : " + strEndTimeMain);
            }
        }

        private static bool MigrateNoteStep2 (Criteria param)
        {
            IBlockConfig blockConfig = ConfigFactory.GetConfig();
            bool statusTransfer = false;
            Console.WriteLine("================================================");
            Console.WriteLine("==       Step 2 : Migrate AS400 To MSSQL      ==");
            Console.WriteLine("================================================");
            Console.WriteLine(string.Format("==  Start Process {0} ==", DateTime.Now));
            statusTransfer = TransferData.Transfer(param);
            Console.WriteLine(string.Format("== End Process {0}  ==", DateTime.Now));
            if (selectFunc == "1F2")
            {
                strEndTimeMain = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
                MailStub.SendEmail(statusTransfer == true ? true : false,
                             blockConfig.EmailFrom,
                             blockConfig.EmailListReceive,
                             blockConfig.CubeName,
                             "To " + blockConfig.NOTE_SYSTEM,
                             string.Format(" From : {0} - To : {1} ", param.start, param.end) + "\n\t Step 2 " + Program.recordSummary + "\n\tStart : " + strStartTimeMain + " Finish : " + strEndTimeMain);
            }
            return statusTransfer;
        }

        private static bool MigrateNoteStep3(Criteria param)
        {
            IBlockConfig blockConfig = ConfigFactory.GetConfig();
            bool status = false;
            Console.WriteLine("================================================");
            Console.WriteLine("==     Step 3 : Process DashBoard & History   ==");
            Console.WriteLine("================================================");
            Console.WriteLine(string.Format("==  Start Process {0} ==", DateTime.Now));
            status = TransferData.ProcessDashBoard(param);
            Console.WriteLine(string.Format("==  End Process {0} ==", DateTime.Now));

            if (selectFunc == "1F3")
            {
                if (status)
                {
                    string text = TransferData.SummaryMigrate(param);
                    strEndTimeMain = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
                    MailStub.SendEmail(true,
                                 blockConfig.EmailFrom,
                                 blockConfig.EmailListReceive,
                                 blockConfig.CubeName,
                                 "To " + blockConfig.NOTE_SYSTEM,
                                 string.Format(" From : {0} - To : {1} ", param.start, param.end) + "\n\t Step 3 " + text + Program.recordSummary + "\n\tStart : " + strStartTimeMain + " Finish : " + strEndTimeMain);
                }
            }
            return status;
        }

        private static void MigrateNote(Criteria param)
        {
            IBlockConfig blockConfig = ConfigFactory.GetConfig();

            bool statusStep2 = false;
            bool statusStep3 = false;
            MigrateNoteStep1(param);
            statusStep2 = MigrateNoteStep2(param);
            if(statusStep2)
            {
                statusStep3 = MigrateNoteStep3(param);
                string text = TransferData.SummaryMigrate(param);

                strEndTimeMain = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");

                if(statusStep3)
                {
                    if (blockConfig.EmailSendWhen == "A")
                    {
                        MailStub.SendEmail(true,
                               blockConfig.EmailFrom,
                               blockConfig.EmailListReceive,
                               blockConfig.CubeName,
                               "To " + blockConfig.NOTE_SYSTEM,
                               string.Format(" From : {0} - To : {1} ", param.start,param.end) + " Step 1 - 3 " + text + Program.recordSummary + "\n\tStart : " + strStartTimeMain + " Finish : " + strEndTimeMain);
                    }
                }
            }
        }

        private static void MigrateNoteSpecialStep1(Criteria param)
        {
            IBlockConfig blockConfig = ConfigFactory.GetConfig();
            Console.WriteLine("===============================================");
            Console.WriteLine("==       Step 1 : Clear Data MSSQL           ==");
            Console.WriteLine("===============================================");
            Console.WriteLine(string.Format("== Start Process {0} ==", DateTime.Now));
            string strStartTime = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            bool status = TransferData.ClearDataSpecialNote(param);
            Console.WriteLine(string.Format("== End Process {0}  ==", DateTime.Now));
            if (selectFunc == "2F1")
            {
                strEndTimeMain = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
                MailStub.SendEmail(status == true ? true : false,
                             blockConfig.EmailFrom,
                             blockConfig.EmailListReceive,
                             blockConfig.CubeName,
                             "To " + blockConfig.NOTE_SYSTEM,
                             string.Format(" From : {0} - To : {1} ", param.start, param.end) + "\n\t Step 1 " + Program.recordSummary + "\n\tStart : " + strStartTime + " Finish : " + strEndTimeMain);
            }
        }

        private static bool MigrateNoteSpecialStep2(Criteria param)
        {
            IBlockConfig blockConfig = ConfigFactory.GetConfig();
            bool statusTransfer = false;
            Console.WriteLine("================================================");
            Console.WriteLine("==       Step 2 : Migrate AS400 To MSSQL      ==");
            Console.WriteLine("================================================");
            Console.WriteLine(string.Format("==  Start Process {0} ==", DateTime.Now));
            statusTransfer = TransferData.TransferSpecialNote(param);
            Console.WriteLine(string.Format("== End Process {0}  ==", DateTime.Now));
            if (selectFunc == "2F2")
            {
                strEndTimeMain = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
                MailStub.SendEmail(statusTransfer == true ? true : false,
                             blockConfig.EmailFrom,
                             blockConfig.EmailListReceive,
                             blockConfig.CubeName,
                             "To " + blockConfig.NOTE_SYSTEM,
                             string.Format(" From : {0} - To : {1} ", param.start, param.end) + "\n\t Step 2 " + Program.recordSummary + "\n\tStart : " + strStartTimeMain + " Finish : " + strEndTimeMain);
            }
            return statusTransfer;
        }

        private static bool MigrateNoteSpecialStep3(Criteria param)
        {
            IBlockConfig blockConfig = ConfigFactory.GetConfig();
            bool status = false;
            Console.WriteLine("================================================");
            Console.WriteLine("==         Step 3 : Process CarfulList        ==");
            Console.WriteLine("================================================");
            Console.WriteLine(string.Format("==  Start Process {0} ==", DateTime.Now));
            status = TransferData.ProcessCarFul(param);
            Console.WriteLine(string.Format("==  End Process {0} ==", DateTime.Now));

            if (selectFunc == "2F3")
            {
                if (status)
                {
                    string text = TransferData.SummaryMigrateSpecialNote(param);
                    strEndTimeMain = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
                    MailStub.SendEmail(true,
                                 blockConfig.EmailFrom,
                                 blockConfig.EmailListReceive,
                                 blockConfig.CubeName,
                                 "To " + blockConfig.NOTE_SYSTEM,
                                 string.Format(" From : {0} - To : {1} ", param.start, param.end) + "\n\t Step 3 " + text + Program.recordSummary + "\n\tStart : " + strStartTimeMain + " Finish : " + strEndTimeMain);
                }
            }
            return status;
        }

        private static void MigrateSpecialNote(Criteria param)
        {
            IBlockConfig blockConfig = ConfigFactory.GetConfig();

            bool statusStep2 = false;
            bool statusStep3 = false;
            MigrateNoteSpecialStep1(param);
            statusStep2 = MigrateNoteSpecialStep2(param);
            if (statusStep2)
            {
                statusStep3 = MigrateNoteSpecialStep3(param);
                string text = TransferData.SummaryMigrateSpecialNote(param);

                strEndTimeMain = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");

                if (statusStep3)
                {
                    if (blockConfig.EmailSendWhen == "A")
                    {
                        MailStub.SendEmail(true,
                               blockConfig.EmailFrom,
                               blockConfig.EmailListReceive,
                               blockConfig.CubeName,
                               "To " + blockConfig.NOTE_SYSTEM,
                               string.Format(" From : {0} - To : {1} ", param.start, param.end) + " Step 1 - 3 " + text + Program.recordSummary + "\n\tStart : " + strStartTimeMain + " Finish : " + strEndTimeMain);
                    }
                }
            }
        }

        private static void Sync()
        {

        }

        private static bool ValidateFormatDate(string value, string dateFormats)
        {
            DateTime tempDate;
            bool validDate = DateTime.TryParseExact(value, dateFormats, DateTimeFormatInfo.InvariantInfo, DateTimeStyles.None, out tempDate);
            if (validDate)
                return true;
            else
                return false;
        }

    }
}
