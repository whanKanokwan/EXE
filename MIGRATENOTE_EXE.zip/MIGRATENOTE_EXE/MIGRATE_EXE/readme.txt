﻿Exe Connect AS400 
- path : D:\Applications\CenterUserAS400
  ** ต้องไป Add New System : NOTE_DB_MSSQL
  ** Data Source={0};Initial Catalog=MIGRATE_NOTE_DB;Persist Security Info=True;User ID={1};Password={2}
 -------------------------------------------------------------------------------
Run Program Exe :
- เปิด cmd
- D:Migrate_Note/App/Migrate_Note.exe 1 F0 01/01/2020 01/05/2020
** Parameter[0] : Menu Migrate Note (ใส่ 1) , Migrate SpecialNote (ใส่ 2)
** Parameter[1] : f0 run ทั้ง 3 Step , f1 run Step 1 , f2 run Step 2 , f3 run Step3
** Parameter[2] : วันที่เริ่ม
** Parameter[3] : วันที่สิ้นสุด
 -------------------------------------------------------------------------------
####################### Config Note #######################
path แก้ไข AppConfig
- D:Migrate_Note/App/Migrate_Note.exe
App.Config : 
- AS400_SOURCE_COUNT : query count จาก AS400 จาก actionCode , resultCode
- MSSQL_DESTINATION_COUNT : query count จาก MSSQL จาก actionCode , resultCode
- AS400_SOURCE_SELECT : query ดึงข้อมูลจาก AS400 
  **ใส่เงื่อนไขวันที่
  **ห้ามให้ Comment -- ใน query
  **เครื่องหมาย < ให้ replace &lt;
  **เครื่องหมาย > ให้ replace &gt;
  **ชื่อ Column ต้องตรงกับ MSSQL 
- MSSQL_STORE_DASHBOARD : List Store MSSQL Server 
  Ex
   {
	'name':'[dbo].[SP_DashBoard_LastContactList]',
    'value':'@csnNo,@contractNo,@actionCode,@personCode,@resultCode,@noteDescription,@noteRemark,@telNo,@noteBy,@noteByName,@UserName,@systemBy'
   }
Email Receiver
 - EmailListReceive : ชื่อ mail ที่ต้องการให้ได้รับ log error
SQL_RECORD
 - ใช้แบ่งรอบในการ ติดต่อ MSSQL โดยจะใช้กับ Step 3 ตอน Call Store DashBoard ส่ง Start , End ไปหา id ของ note_analytics แล้ว cursor exe store_dashboard
 -------------------------------------------------------------------------------
 ####################### Config Special Note #######################
 path แก้ไข AppConfig
- D:Migrate_Note/App/Migrate_Note.exe
App.Config : 
- AS400_SOURCE_COUNT_SPECIAL_NOTE : query count จาก AS400 จาก actionCode , resultCode
- MSSQL_DESTINATION_COUNT_SPECIAL_NOTE  : query count จาก MSSQL จาก actionCode , resultCode
- AS400_SOURCE_SELECT_SPECIAL_NOTE : query ดึงข้อมูลจาก AS400 อยู่ในรุปแบบ [{'name':'xx','value':'yyy'}]
  **ใน value ห้ามใส่ '' ต้องอยู่ในรุปแบบ \'\' เท่านั้น
  **ห้ามให้ Comment -- ใน query
  **เครื่องหมาย < ให้ replace &lt;
  **เครื่องหมาย > ให้ replace &gt;
  **ชื่อ Column ต้องตรงกับ MSSQL 
 - MSSQL_STORE_DASHBOARD_CF : List Store MSSQL Server 
 -------------------------------------------------------------------------------