﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.DALService
{
    internal class DALBasic
    {

        private DALServiceDBType dbType = DALServiceDBType.DbAS400;

        public enum DALServiceDBType
        {
            DbAS400 = 1,
            DBMSSQL = 2
        }

        public DALServiceDBType DBType
        {
            set { dbType = value; }
            get { return dbType; }
        }

        public string GetDbSqlConnection(string systemName)
        {
            ClassAS400User.ClassAS400Usercl con = new ClassAS400User.ClassAS400Usercl(systemName);
            string strCon = string.Format(con.Get_ConnectionString(),
                                            con.Get_AS400IP(),
                                            con.Get_UserName(),
                                            con.Get_Password());
            return strCon;
        }

        public string GetDataBase(string systemName)
        {
            ClassAS400User.ClassAS400Usercl con = new ClassAS400User.ClassAS400Usercl(systemName);
            string strDB = con.Get_DataBase();
            return strDB;
        }
       
    }
}
