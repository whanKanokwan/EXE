﻿using MIGRATE_EXE.DALService;
using MIGRATE_EXE.log;
using MIGRATE_EXE.Models;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.DALService
{
    internal class DALMSSQL : DALBasic , IDALClass
    {
        private SqlConnection con = new SqlConnection();
        private SqlDataReader myReader;
        private string system;
        private SqlTransaction tr = null;
        private int commandTimeout = -1;
        private string lastError;

        public bool SetCommandTimeout(int cto)
        {
            if(cto != null)
            {
                commandTimeout = cto;
            }
            return true;
        }
        public bool OpenConnection()
        {
            bool bRet = false;
            try
            {
                if(con.State != System.Data.ConnectionState.Open)
                {
                    con.ConnectionString = this.GetDbSqlConnection(system);
                    con.Open();
                }
                try
                {
                    tr = con.BeginTransaction();
                }
                catch(Exception ex)
                {

                }

                bRet = true;
            }
            catch(SqlException ex)
            {
                con.Close();
                bRet = false;
            }

            return bRet;
        }

        public DALMSSQL(string sys)
        {
            this.DBType = DALServiceDBType.DBMSSQL;
            this.system = sys;
        }

        public bool CloseConnection()
        {
            con.Close();
            return true;
        }
        
        public DataSet ExecuteDataSet(string sql  , ref string strExeption )
        {
            DataSet ds = new DataSet();
            try
            {
                if (!OpenConnection())
                    return null;

                SqlCommand cmd = new SqlCommand();
                if(commandTimeout >= 0)
                {
                    cmd.CommandTimeout = commandTimeout;
                }
                cmd.Connection = con;
                cmd.Transaction = tr;
                cmd.CommandText = sql;

                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
            }
            catch(SqlException ex)
            {
                strExeption = ex.Message;
                CloseConnection();
            }

            CloseConnection();

            return ds;
        }

        public bool ExecuteDataSetOfSet(string sql, ref DataSet ds, ref string strExeption)
        {
            bool status = false;
            try
            {
                if (!OpenConnection())
                    return status;

                SqlCommand cmd = new SqlCommand();
                if (commandTimeout >= 0)
                {
                    cmd.CommandTimeout = commandTimeout;
                }
                cmd.Connection = con;
                cmd.Transaction = tr;
                cmd.CommandText = sql;

                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                status = true;
            }
            catch (SqlException ex)
            {
                strExeption = ex.Message;
                CloseConnection();
                status = false;
            }

            CloseConnection();

            return status;
        }

        public bool ExecuteSql(object obj , ref string strExeption)
        {
            bool bRet = false;
            SqlCommand cmd = null;
            try
            {
                if (!OpenConnection())
                {
                    return bRet;
                }
                try
                {
                    cmd = null;
                 
                        cmd = obj as SqlCommand;

                        if (cmd is SqlCommand)
                        {
                            if (commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.Connection = con;
                            cmd.Transaction = tr;
                            cmd.ExecuteNonQuery();
                        }
                        else if (obj is string)
                        {
                            cmd = new SqlCommand();
                            if (commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.Connection = con;
                            cmd.CommandText = obj as string;
                            cmd.Transaction = tr;
                            cmd.ExecuteNonQuery();
                        }
                  

                    tr.Commit();
                    bRet = true;
                }
                catch (SqlException ex)
                {
                    tr.Rollback();
                    bRet = false;
                    CloseConnection();

                    lastError = ex.Message.ToString().Trim();
                    strExeption = lastError;
                    //Logger.WriteTrace(false, "---------------- Error from : MSSQL MIGRATE_EXE.DALService.ExecuteSql --------------");
                    //Logger.WriteTrace(false, lastError);
                    Console.WriteLine(lastError);

                    if (cmd != null)
                    {
                        if (cmd is SqlCommand)
                        {
                            string strValue = "";
                            foreach (SqlParameter param in cmd.Parameters)
                            {
                                strValue += param.ParameterName + " = " + (param.Value ?? "Null") + "//";
                            }

                            //Logger.WriteTrace(false, strValue);
                        }
                        else
                        {
                            if (cmd is string)
                            {
                                //Logger.WriteTrace(false, cmd.ToString());
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                CloseConnection();
                bRet = false;
                lastError = ex.Message.ToString().Trim();
                strExeption = lastError;
            }

            CloseConnection();
            return bRet;

        }

        public bool ExecuteTransSql(ArrayList arList , ref string strException )
        {
            string temp = string.Empty;
            bool bRet = false;
            SqlCommand cmd = null;
            try
            {
                if(!OpenConnection())
                {
                    return bRet;
                }

                try
                {
                    cmd = null;
                    int index = 1;
                    foreach(object obj in arList)
                    {
                        Console.WriteLine("Exec SQL {0} of {1}", index, arList.Count);
                        cmd = obj as SqlCommand;

                        if(cmd is SqlCommand)
                        {
                            if(cmd.Parameters.Count > 0)
                            {
                                Console.WriteLine(cmd.Parameters[0].ParameterName + ":" + cmd.Parameters[0].Value);
                                Console.WriteLine(cmd.Parameters[1].ParameterName + ":" + cmd.Parameters[1].Value);
                                Console.WriteLine(cmd.Parameters[2].ParameterName + ":" + cmd.Parameters[2].Value);
                            }
                           
                            if (commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.Connection = con;
                            cmd.Transaction = tr;
                            cmd.ExecuteNonQuery();
                        }
                        else if (obj is string)
                        {
                            cmd = new SqlCommand();
                            if(commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.Connection = con;
                            cmd.CommandText = obj as string;
                            if(cmd.Parameters.Count > 0)
                            {
                                Console.WriteLine(cmd.Parameters[0].ParameterName + ":" + cmd.Parameters[0].Value);
                                Console.WriteLine(cmd.Parameters[1].ParameterName + ":" + cmd.Parameters[1].Value);
                                Console.WriteLine(cmd.Parameters[2].ParameterName + ":" + cmd.Parameters[2].Value);
                            }
                            cmd.Transaction = tr;
                            cmd.ExecuteNonQuery();
                        }
                        index++;
                    }

                    tr.Commit();
                    bRet = true;
                }
                catch (SqlException ex)
                {
                    tr.Rollback();
                    bRet = false;
                    CloseConnection();

                    lastError = ex.Message.ToString().Trim();
                    //Logger.WriteTrace(false, "---------------- Error from : MSSQL MIGRATE_EXE.DALService.ExecuteTransSql --------------");
                    //Logger.WriteTrace(false, lastError);
                    Console.WriteLine(lastError);

                    strException = lastError;

                    if (cmd != null)
                    {
                        if (cmd is SqlCommand)
                        {
                            string strValue = "";
                            foreach (SqlParameter param in cmd.Parameters)
                            {
                                if(param.ParameterName.ToUpper() == "CSNNO")
                                {
                                    temp = param.Value.ToString();
                                }
                                strValue += param.ParameterName + " = " + (param.Value ?? "Null") + "//";
                            }

                            strException += strValue;

                            //Logger.WriteTrace(false, strValue);
                        }
                        else
                        {
                            if (cmd is string)
                            {
                                //Logger.WriteTrace(false, cmd.ToString());
                                strException += cmd.ToString();
                            }
                        }
                    }
                }
            }
            catch(SqlException ex)
            {
                CloseConnection();
                bRet = false;
                lastError = ex.Message.ToString().Trim();
            }

            if(!string.IsNullOrEmpty(temp))
            {
                strException += "|" + temp;
            }

            CloseConnection();
            return bRet;
           
        }

        public bool ExecuteTransSqlLot(ArrayList arList, int records)
        {
            bool bRet = false;

            try
            {
                if (!OpenConnection())
                    return bRet;

                try
                {
                    SqlCommand cmd = null;
                    int rounds = 0;
                    foreach (object obj in arList)
                    {
                        rounds++;
                        if (obj is SqlCommand)
                        {
                            cmd = obj as SqlCommand;
                            cmd.Connection = con;
                            cmd.Transaction = tr;
                            if (commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.ExecuteNonQuery();
                        }
                        else if (obj is string)
                        {
                            cmd = new SqlCommand();
                            cmd.Connection = con;
                            cmd.CommandText = obj as String;
                            cmd.Transaction = tr;
                            if (commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.ExecuteNonQuery();
                        }
                        if (rounds >= records)
                        {
                            tr.Commit();
                            rounds = 0;
                        }
                    }

                    bRet = true;
                }
                catch (Exception ex)
                {
                    tr.Rollback();
                    bRet = false;
                    CloseConnection();
                    lastError = ex.Message.ToString().Trim();
                }
            }
            catch (SqlException ex)
            {
                CloseConnection();
                bRet = false;
                lastError = ex.Message.ToString().Trim();
            }
            CloseConnection();
            return bRet;

        }

        public bool CallProcedure(string procedureName, string param1, string param2, ref string strMsg)
        {
            try
            {
                string pgm_name = procedureName;
                bool bRet = false;
                if (pgm_name.Trim() == "")
                {
                    return true;
                }

                IDbCommand cmd = new SqlCommand();

                int exePro = 0;
                string flag = "N";
                strMsg = "";

                cmd.CommandText = pgm_name.Trim();
                cmd.CommandType = CommandType.StoredProcedure;
                if (commandTimeout >= 0)
                {
                    cmd.CommandTimeout = commandTimeout;
                }

                IDbDataParameter dp1 = new SqlParameter("PI_USER", SqlDbType.VarChar, 10);
                dp1.Value = param1;
                IDbDataParameter dp2 = new SqlParameter("PI_PC", SqlDbType.VarChar, 10);
                dp2.Value = param2;
                IDbDataParameter dp3 = new SqlParameter("PO_DES", SqlDbType.VarChar, 255);
                dp3.Direction = ParameterDirection.Output;
                IDbDataParameter dp4 = new SqlParameter("PO_FLG", SqlDbType.VarChar, 1);
                dp4.Direction = ParameterDirection.Output;

                cmd.Parameters.Add(dp1);
                cmd.Parameters.Add(dp2);
                cmd.Parameters.Add(dp3);
                cmd.Parameters.Add(dp4);

                exePro = ExecuteProcedure(ref cmd);
                if (exePro > 0)
                {
                    strMsg = dp3.Value.ToString().Trim() == null ? "" : dp3.Value.ToString().Trim();
                    flag = dp4.Value == null ? "N" : dp4.Value.ToString();
                    if (flag == "Y")
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    strMsg = lastError.Trim();
                }

            }
            catch (Exception ex)
            {
                strMsg = "Error Message=" + ex.Message;
            }

            return false;
        }

        public int ExecuteProcedure(ref IDbCommand cmd)
        {
            int iRet = -1;
            try
            {
                if (!OpenConnection())
                    return iRet;

                cmd.Connection = con;
                cmd.Transaction = tr;
                if (commandTimeout >= 0)
                {
                    cmd.CommandTimeout = commandTimeout;
                }

                cmd.ExecuteNonQuery();
                tr.Commit();
                iRet = 1;
            }
            catch (SqlException ex)
            {
                tr.Rollback();
                CloseConnection();
                lastError = "ErrorMessage=" + ex.Message;
                Console.WriteLine(lastError);
            }

            CloseConnection();
            return iRet;
        }

        public bool SetDataReader(string command, ref int numRows)
        {
            try
            {
                if (!OpenConnection())
                    return false;
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                if (commandTimeout >= 0)
                {
                    cmd.CommandTimeout = commandTimeout;
                }
                cmd.Transaction = tr;
                cmd.CommandText = command;

                myReader = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(myReader);
                numRows = dt.Rows.Count;
            }
            catch (SqlException ex)
            {
                lastError = ex.Message.ToString().Trim();
                return false;
            }

            return true;
        }

        public bool BulkCopy(DataTable dataTable , string tableName , ref string strException)
        {
            bool status = false;

            string strExceptionExecuteDataSet = string.Empty;

            try
            {
                    try
                    {
                        using (var bulkCopy = new SqlBulkCopy(this.GetDbSqlConnection(system), SqlBulkCopyOptions.KeepIdentity))
                        {
                            // my DataTable column names match my SQL Column names, so I simply made this loop. However if your column names don't match, just pass in which data table name matches the SQL column name in Column Mappings
                            bulkCopy.BulkCopyTimeout = 1000000;
                            bulkCopy.DestinationTableName = tableName;
                            foreach (DataColumn col in dataTable.Columns)
                            {
                                bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                            }
                            bulkCopy.WriteToServer(dataTable);
                        }
                        status = true;
                    }
                    catch (Exception ex)
                    {
                        strException = ex.Message.ToString();
                        status = false;
                    }

            }
            catch(Exception ex)
            {
                strException = strException;
                status = false;
            }

       
            return status;
        }

        public IDbCommand CreateCommand()
        {
            return new SqlCommand();
        }

        public bool ReadMyReader(ref Object[] myValues)
        {
            if(myReader.Read())
            {
                Object[] values = new Object[myReader.FieldCount];
                int fieldCount = myReader.GetValues(values);
                myValues = values;

                return true;
            }
            else
            {
                return false;
            }
        }

        public bool ExecuteStoreProcedureLot(List<StoreProcedureList> arList , ref string strExeption)
        {
            bool status = false;
            try
            {
                if (!OpenConnection())
                {
                    return status;
                }

                try
                {
                    foreach (var obj in arList)
                    {
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = con;
                        cmd.CommandText = obj.spName;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Transaction = tr;

                        foreach (SqlParameter param in (SqlParameterCollection)obj.parameters)
                        {
                            cmd.Parameters.AddWithValue(param.ParameterName, param.SqlDbType).Value = param.Value;
                        }

                        cmd.ExecuteNonQuery();
                    }

                    tr.Commit();
                    status = true;
                }
                catch (Exception ex)
                {
                    strExeption = ex.Message.ToString();
                    status = false;
                }
            }
            catch (Exception ex)
            {
                strExeption = ex.Message.ToString();
                status = false;
            }

            return status;
        }

        public DataSet ExecuteStoreProcedure(string spName , object parameters, ref string strException)
        {
            DataSet ds = new DataSet();

            SqlCommand cmd = new SqlCommand();
            try
            {
                if (!OpenConnection())
                    return null;
                cmd.Connection = con;
                cmd.CommandText = spName;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = tr;
                if (commandTimeout >= 0)
                {
                    cmd.CommandTimeout = commandTimeout;
                }
                cmd.Transaction = tr;
                foreach (SqlParameter param in (SqlParameterCollection)parameters)
                {
                    cmd.Parameters.Add(param.ParameterName, param.SqlDbType).Value = param.Value;
                }

                SqlDataAdapter ada = new SqlDataAdapter(cmd);
                ada.Fill(ds);
                tr.Commit();
            }
            catch (SqlException ex)
            {
                tr.Rollback();
                CloseConnection();
                lastError = ex.Message;
                strException = lastError;
                //Logger.WriteTrace(false, string.Format("---------------- Error from : MSSQL MIGRATE_EXE.DALService.ExecuteStoreProcedure {0} --------------",spName));
                //Logger.WriteTrace(false, lastError);

                string strValue = "";
                foreach (SqlParameter param in cmd.Parameters)
                {
                    strValue += param.ParameterName + " = " + (param.Value ?? "Null") + "//";
                }

                strException += strValue;
                //Logger.WriteTrace(false, strValue);
            }

            CloseConnection();

            return ds;
        }

        public List<Result> ExecuteScalarTransSql(List<Param> arList)
        {

            List<Result> listResult = new List<Result>();
            SqlCommand cmd = null;
            try
            {
                if (!OpenConnection())
                {
                    // Connect Base ไม่ได้ 
                    return null;
                }

                try
                {
                    cmd = null;
                    foreach (var obj in arList)
                    {

                        Result rs = new Result();
                        cmd = (object)obj.value as SqlCommand;

                        if (cmd is SqlCommand)
                        {
                            if (commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.Connection = con;
                            cmd.Transaction = tr;
                            rs.name = obj.name;
                            rs.value = Convert.ToInt32(cmd.ExecuteScalar());
                            rs.text = string.Format("Number of " + obj.name + " is : {0}",rs.value);
                        }
                        else if (obj.value is string)
                        {
                            cmd = new SqlCommand();
                            if (commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.Connection = con;
                            cmd.CommandText = obj.value as string;
                            cmd.Transaction = tr;
                            rs.name = obj.name;
                            rs.value = Convert.ToInt32(cmd.ExecuteScalar());
                            rs.text = string.Format("Number of " + obj.name + " is : {0}", rs.value);
                        }

                        listResult.Add(rs);
                    }

                    tr.Commit();
                }
                catch (SqlException ex)
                {
                    tr.Rollback();
                    CloseConnection();

                    lastError = ex.Message.ToString().Trim();
                    //Logger.WriteTrace(false, "---------------- Error from : MSSQL MIGRATE_EXE.DALService.ExecuteScalarTransSql --------------");
                    //Logger.WriteTrace(false, lastError);
                    Console.WriteLine(lastError);

                    if (cmd != null)
                    {
                        if (cmd is SqlCommand)
                        {
                            string strValue = "";
                            foreach (SqlParameter param in cmd.Parameters)
                            {
                                strValue += param.ParameterName + " = " + (param.Value ?? "Null") + "//";
                            }

                            //Logger.WriteTrace(false, strValue);
                        }
                        else
                        {
                            if (cmd is string)
                            {
                                //Logger.WriteTrace(false, cmd.ToString());
                            }
                        }
                    }
                }
                
            }
            catch (SqlException ex)
            {
                CloseConnection();
                lastError = ex.Message.ToString().Trim();
            }
            CloseConnection();
            return listResult;

        }

        public int GetMyReaderFieldCount()
        {
            int fieldCount = myReader.FieldCount;
            return fieldCount;
        }
    }
}
