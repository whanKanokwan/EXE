﻿using IBM.Data.DB2.iSeries;
using MIGRATE_EXE.Commons;
using MIGRATE_EXE.log;
using MIGRATE_EXE.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.DALService
{
    internal class DALAS400 : DALBasic, IDALClass
    {
        public string lastError;
        private iDB2Connection con = new iDB2Connection();
        private iDB2Transaction tr = null;
        private iDB2DataReader myReader;
        private string system;
        private int commandTimeout = -1;
        public bool assignLibFlag = false;

        public bool SetCommandTimeout(int cto)
        {
            if (cto != null)
            {
                commandTimeout = cto;
            }
            return true;
        }

        public DALAS400(string sys)
        {
            this.DBType = DALServiceDBType.DbAS400;
            this.system = sys;
        }

        public bool AssignAuthenticationLib()
        {
            bool bRet = false;
            string strLib = AppConfig.AS400AssignLib;

            iDB2Command cmd = new iDB2Command();
            try
            {
                cmd.Connection = con;
                cmd.Transaction = tr;
                cmd.CommandTimeout = 30;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "CALL " + strLib + "/HMSRBKCL";
                cmd.ExecuteNonQuery();
                bRet = true;
                assignLibFlag = true;
            }
            catch (Exception ex)
            {
                bRet = false;
            }

            return bRet;
        }

        public bool OpenConnection()
        {
            bool bRet = false;
            try
            {
                if (con.State != System.Data.ConnectionState.Open)
                {
                    con.ConnectionString = this.GetDbSqlConnection(system);
                    con.Open();
                    try
                    {
                        tr = con.BeginTransaction();
                    }
                    catch (Exception ex)
                    {

                    }

                    AssignAuthenticationLib();
                }
                else
                {
                    try
                    {
                        tr = con.BeginTransaction();
                    }
                    catch (Exception ex)
                    {

                    }
                }

                bRet = true;
            }
            catch (iDB2Exception ex)
            {
                con.Close();
                bRet = false;
                lastError = ex.Message.ToString().Trim();
            }
            return bRet;
        }

        public bool CloseConnection()
        {
            con.Close();
            return true;
        }

        public DataSet ExecuteDataSet(string sql , ref string strException)
        {
            DataSet ds = new DataSet();
            try
            {
                if (!OpenConnection())
                {
                    Console.WriteLine("Error --> cann't connect as400");
                    //Logger.WriteTrace(false, "Error --> cann't  connect as400");
                    return null;
                }

                iDB2Command cmd = new iDB2Command();
                cmd.Connection = con;
                cmd.Transaction = tr;
                if (commandTimeout >= 0)
                {
                    cmd.CommandTimeout = commandTimeout;
                }
                cmd.CommandText = sql;

                iDB2DataAdapter adp = new iDB2DataAdapter(cmd);
                adp.Fill(ds);
            }
            catch (iDB2Exception ex)
            {
                CloseConnection();
                lastError = ex.Message.ToString().Trim();
                Console.WriteLine("Error Exception --> " + lastError);
                strException = lastError;
                //Logger.WriteTrace(false, "Error Exception --> " + lastError);
            }
            CloseConnection();

            return ds;
        }

        public bool ExecuteDataSetOfSet(string sql, ref DataSet ds, ref string strException)
        {
            bool status = false;
            try
            {
                if (!OpenConnection())
                {
                    Console.WriteLine("Error --> cann't connect as400");
                    //Logger.WriteTrace(false, "Error --> cann't  connect as400");
                    return status;
                }

                iDB2Command cmd = new iDB2Command();
                cmd.Connection = con;
                cmd.Transaction = tr;
                if (commandTimeout >= 0)
                {
                    cmd.CommandTimeout = commandTimeout;
                }
                cmd.CommandText = sql;

                iDB2DataAdapter adp = new iDB2DataAdapter(cmd);
                adp.Fill(ds);
                status = true;
            }
            catch (iDB2Exception ex)
            {
                status = false;
                CloseConnection();
                lastError = ex.Message.ToString().Trim();
                Console.WriteLine("Error Exception --> " + lastError);
                strException = lastError;
                //Logger.WriteTrace(false, "Error Exception --> " + lastError);
                status = false;

            }
            CloseConnection();

            return status;
        }

        public bool ExecuteSql(object obj , ref string strException)
        {
            bool bRet = false;
            iDB2Command cmd = null;
            try
            {
                if (!OpenConnection())
                {
                    return bRet;
                }

                try
                {
                    cmd = null;
                  
                        if (obj is iDB2Command)
                        {
                            cmd = obj as iDB2Command;
                            cmd.Connection = con;
                            cmd.Transaction = tr;
                            cmd.ExecuteNonQuery();
                        }
                        else if (obj is string)
                        {
                            cmd = new iDB2Command();
                            cmd.Connection = con;
                            cmd.CommandText = obj as String;
                            cmd.Transaction = tr;
                            cmd.ExecuteNonQuery();

                        }
                   
                    tr.Commit();
                    bRet = true;
                }
                catch (iDB2Exception ex)
                {
                    tr.Rollback();
                    bRet = false;
                    CloseConnection();

                    lastError = ex.Message.ToString().Trim();
                    strException = lastError;
                    //Logger.WriteTrace(false, "---------------- Error from : AS400 MIGRATE_EXE.DALService.ExecuteTransSql --------------");
                    //Logger.WriteTrace(false, lastError);
                    Console.WriteLine(lastError);

                    if (cmd != null)
                    {
                        if (cmd is iDB2Command)
                        {
                            string strValue = "";
                            foreach (iDB2Parameter param in cmd.Parameters)
                            {
                                strValue += param.ParameterName + " = " + (param.Value ?? "Null") + "//";
                            }

                            //Logger.WriteTrace(false, strValue);
                        }
                        else
                        {
                            if (cmd is string)
                            {
                                //Logger.WriteTrace(false, cmd.ToString());
                            }
                        }
                    }
                }
            }
            catch (iDB2Exception ex)
            {
                CloseConnection();
                bRet = false;
                lastError = ex.Message.ToString().Trim();
                strException = lastError;
            }

            CloseConnection();
            return bRet;
        }

        public bool ExecuteTransSql(ArrayList arList , ref string strException )
        {
            bool bRet = false;
            iDB2Command cmd = null;
            try
            {
                if (!OpenConnection())
                {
                    return bRet;
                }

                try
                {
                    cmd = null;
                    foreach (object obj in arList)
                    {
                        if (obj is iDB2Command)
                        {
                            cmd = obj as iDB2Command;
                            cmd.Connection = con;
                            cmd.Transaction = tr;
                            cmd.ExecuteNonQuery();
                        }
                        else if (obj is string)
                        {
                            cmd = new iDB2Command();
                            cmd.Connection = con;
                            cmd.CommandText = obj as String;
                            cmd.Transaction = tr;
                            cmd.ExecuteNonQuery();

                        }
                    }
                    tr.Commit();
                    bRet = true;
                }
                catch (iDB2Exception ex)
                {
                    tr.Rollback();
                    bRet = false;
                    CloseConnection();

                    lastError = ex.Message.ToString().Trim();
                    //Logger.WriteTrace(false, "---------------- Error from : AS400 MIGRATE_EXE.DALService.ExecuteTransSql --------------");
                    //Logger.WriteTrace(false, lastError);
                    Console.WriteLine(lastError);

                    if (cmd != null)
                    {
                        if (cmd is iDB2Command)
                        {
                            string strValue = "";
                            foreach (iDB2Parameter param in cmd.Parameters)
                            {
                                strValue += param.ParameterName + " = " + (param.Value ?? "Null") + "//";
                            }

                            //Logger.WriteTrace(false, strValue);
                        }
                        else
                        {
                            if (cmd is string)
                            {
                                //Logger.WriteTrace(false, cmd.ToString());
                            }
                        }
                    }
                }
            }
            catch (iDB2Exception ex)
            {
                CloseConnection();
                bRet = false;
                lastError = ex.Message.ToString().Trim();
            }

            CloseConnection();
            return bRet;
        }

        public bool ExecuteTransSqlLot(ArrayList arList, int records)
        {
            bool bRet = false;

            try
            {
                if (!OpenConnection())
                    return bRet;

                try
                {
                    iDB2Command cmd = null;
                    int rounds = 0;
                    foreach(object obj in arList)
                    {
                        rounds++;
                        if(obj is iDB2Command)
                        {
                            cmd = obj as iDB2Command;
                            cmd.Connection = con;
                            cmd.Transaction = tr;
                            if (commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.ExecuteNonQuery();
                        }
                        else if (obj is string)
                        {
                            cmd = new iDB2Command();
                            cmd.Connection = con;
                            cmd.CommandText = obj as String;
                            cmd.Transaction = tr;
                            if (commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.ExecuteNonQuery();
                        }
                        if (rounds >= records)
                        {
                            tr.Commit();
                            rounds = 0;
                        }
                    }

                    bRet = true;
                }
                catch(Exception ex)
                {
                    tr.Rollback();
                    bRet = false;
                    CloseConnection();
                    lastError = ex.Message.ToString().Trim();
                }
            }
            catch(iDB2Exception ex)
            {
                CloseConnection();
                bRet = false;
                lastError = ex.Message.ToString().Trim();
            }
            CloseConnection();
            return bRet;

        }

        public bool ExecuteSubRoutine(string pgm, iDB2ParameterCollection parameters)
        {
            bool bRet = false;
            iDB2Command cmd = null;
            try
            {
                if (!OpenConnection())
                {
                    return bRet;
                }

                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = pgm.ToString();
                foreach (iDB2Parameter parameter in parameters)
                {
                    cmd.Parameters.AddWithValue(parameter.ParameterName, parameter.iDB2DbType).Value = parameter.Value;
                }
                cmd.Transaction = tr;
                cmd.ExecuteNonQuery();
            }
            catch (iDB2Exception ex)
            {
                bRet = false;
                CloseConnection();

                lastError = ex.Message.ToString().Trim();
                //Logger.WriteTrace(false, "---------------- Error from : AS400 MIGRATE_EXE.DALService.ExecuteSubRoutine --------------");
                //Logger.WriteTrace(false, lastError);
                Console.WriteLine(lastError);
            }

            CloseConnection();
            return bRet;
        }

        public DataSet ExecuteSubRoutineDs(string pgm, iDB2ParameterCollection parameters)
        {
            DataSet ds = new DataSet();
            iDB2Command cmd = null;
            try
            {
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = pgm.ToString();
                foreach (iDB2Parameter parameter in parameters)
                {
                    cmd.Parameters.AddWithValue(parameter.ParameterName, parameter.iDB2DbType).Value = parameter.Value;
                }
                cmd.Transaction = tr;

                iDB2DataAdapter adp = new iDB2DataAdapter(cmd);

                adp.Fill(ds);
            }
            catch (iDB2Exception ex)
            {
                CloseConnection();

                lastError = ex.Message.ToString().Trim();
                //Logger.WriteTrace(false, "---------------- Error from : AS400 MIGRATE_EXE.DALService.ExecuteSubRoutineDs --------------");
                //Logger.WriteTrace(false, lastError);
                Console.WriteLine(lastError);
            }

            CloseConnection();
            return ds;
        }

        public bool CallProcedure(string procedureName, string param1, string param2, ref string strMsg)
        {
            try
            {
                string pgm_name = procedureName;
                bool bRet = false;
                if (pgm_name.Trim() == "")
                {
                    return true;
                }

                IDbCommand cmd = new iDB2Command();

                int exePro = 0;
                string flag = "N";
                strMsg = "";

                cmd.CommandText = pgm_name.Trim();
                cmd.CommandType = CommandType.StoredProcedure;
                if (commandTimeout >= 0)
                {
                    cmd.CommandTimeout = commandTimeout;
                }

                IDbDataParameter dp1 = new iDB2Parameter("PI_USER", iDB2DbType.iDB2Char, 10);
                dp1.Value = param1;
                IDbDataParameter dp2 = new iDB2Parameter("PI_PC", iDB2DbType.iDB2Char, 10);
                dp2.Value = param2;
                IDbDataParameter dp3 = new iDB2Parameter("PO_DES", iDB2DbType.iDB2Char, 255);
                dp3.Direction = ParameterDirection.Output;
                IDbDataParameter dp4 = new iDB2Parameter("PO_FLG", iDB2DbType.iDB2Char, 1);
                dp4.Direction = ParameterDirection.Output;

                cmd.Parameters.Add(dp1);
                cmd.Parameters.Add(dp2);
                cmd.Parameters.Add(dp3);
                cmd.Parameters.Add(dp4);

                exePro = ExecuteProcedure(ref cmd);
                if(exePro > 0)
                {
                    strMsg = dp3.Value.ToString().Trim() == null ? "" : dp3.Value.ToString().Trim();
                    flag = dp4.Value == null ? "N" : dp4.Value.ToString();
                    if (flag == "Y")
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    strMsg = lastError.Trim();
                }

            }
            catch (Exception ex)
            {
                strMsg = "Error Message=" + ex.Message;
            }

            return false;
        }

        public int ExecuteProcedure(ref IDbCommand cmd)
        {
            int iRet = -1;
            try
            {
                if (!OpenConnection())
                    return iRet;

                cmd.Connection = con;
                cmd.Transaction = tr;
                if(commandTimeout >= 0)
                {
                    cmd.CommandTimeout = commandTimeout;
                }

                cmd.ExecuteNonQuery();
                tr.Commit();
                iRet = 1;
            }
            catch(iDB2Exception ex)
            {
                tr.Rollback();
                CloseConnection();
                lastError = "ErrorMessage=" + ex.Message;
                //Logger.WriteTrace(false, lastError);
            }

            CloseConnection();
            return iRet;
        }

        public bool SetDataReader(string command, ref int numRows)
        {
            try
            {
                if (!OpenConnection())
                    return false;
                iDB2Command cmd = new iDB2Command();
                cmd.Connection = con;
                if (commandTimeout >= 0)
                {
                    cmd.CommandTimeout = commandTimeout;
                }
                cmd.Transaction = tr;
                cmd.CommandText = command;

                myReader = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(myReader);
                numRows = dt.Rows.Count;
            }
            catch(iDB2Exception ex)
            {
                lastError = ex.Message.ToString().Trim();
                return false;
            }

            return true;
        }

        public bool BulkCopy(DataTable dataTable, string tableName, ref string strException)
        {
            return true;
        }

        public IDbCommand CreateCommand()
        {
            return new iDB2Command();
        }

        public bool ReadMyReader(ref Object[] myValues)
        {
            if(myReader.Read())
            {
                Object[] values = new Object[myReader.FieldCount];
                int fieldCount = myReader.GetiDB2Values(values);
                myValues = values;

                return true;
            }
            else
            {
                return false;
            }
        }

        public bool ExecuteStoreProcedureLot(List<StoreProcedureList> arList, ref string strExeption)
        {
            bool status = false;
            try
            {
                if (!OpenConnection())
                {
                    return status;
                }

                try
                {
                    foreach (var obj in arList)
                    {
                        iDB2Command cmd = new iDB2Command();
                        cmd.Connection = con;
                        cmd.CommandText = obj.spName;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Transaction = tr;

                        foreach (iDB2Parameter param in (iDB2ParameterCollection)obj.parameters)
                        {
                            cmd.Parameters.AddWithValue(param.ParameterName, param.iDB2DbType).Value = param.Value;
                        }

                        cmd.ExecuteNonQuery();
                    }

                    tr.Commit();
                    status = true;
                }
                catch (Exception ex)
                {
                    tr.Rollback();
                    strExeption = ex.Message.ToString();
                    status = false;
                }
            }
            catch (Exception ex)
            {
                tr.Rollback();
                strExeption = ex.Message.ToString();
                status = false;
            }

            return status;
        }

        public DataSet ExecuteStoreProcedure(string spName, object parameters, ref string strExeption)
        {
            DataSet ds = new DataSet();
            try
            {
                iDB2Command cmd = new iDB2Command();

                if (!OpenConnection())
                    return null;
                cmd.Connection = con;
                cmd.CommandText = spName;
                cmd.CommandType = CommandType.StoredProcedure;

                foreach (iDB2Parameter param in (iDB2ParameterCollection)parameters)
                {
                    cmd.Parameters.AddWithValue(param.ParameterName, param.iDB2DbType).Value = param.Value;
                }

                iDB2DataAdapter adp = new iDB2DataAdapter(cmd);
                adp.Fill(ds);
            }
            catch (iDB2Exception ex)
            {
                CloseConnection();
                lastError = "ErrorMessage=" + ex.Message;
                strExeption = lastError;
                //Logger.WriteTrace(false, lastError);
            }

            CloseConnection();

            return ds;
        }

        public List<Result> ExecuteScalarTransSql(List<Param> arList)
        {

            List<Result> listResult = new List<Result>();
            iDB2Command cmd = null;
            try
            {
                if (!OpenConnection())
                {
                    // Connect Base ไม่ได้ 
                    return null;
                }

                try
                {
                    cmd = null;
                    foreach (var obj in arList)
                    {

                        Result rs = new Result();
                        cmd = (object)obj.value as iDB2Command;

                        if (cmd is iDB2Command)
                        {
                            if (commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.Connection = con;
                            cmd.Transaction = tr;
                            rs.name = obj.name;
                            rs.value = Convert.ToInt32(cmd.ExecuteScalar());
                            rs.text = string.Format("Number of " + obj.name + " is : {0}", rs.value);
                        }
                        else if (obj.name is string)
                        {
                            cmd = new iDB2Command();
                            if (commandTimeout >= 0)
                            {
                                cmd.CommandTimeout = commandTimeout;
                            }
                            cmd.Connection = con;
                            cmd.CommandText = obj.name as string;
                            cmd.Transaction = tr;
                            rs.name = obj.name;
                            rs.value = Convert.ToInt32(cmd.ExecuteScalar());
                            rs.text = string.Format("Number of " + obj.name + " is : {0}", rs.value);
                        }

                        listResult.Add(rs);
                    }

                    tr.Commit();
                }
                catch (iDB2Exception ex)
                {
                    tr.Rollback();
                    CloseConnection();

                    lastError = ex.Message.ToString().Trim();
                    //Logger.WriteTrace(false, "---------------- Error from : MSSQL MIGRATE_EXE.DALService.ExecuteScalarTransSql --------------");
                    //Logger.WriteTrace(false, lastError);
                    Console.WriteLine(lastError);

                    if (cmd != null)
                    {
                        if (cmd is iDB2Command)
                        {
                            string strValue = "";
                            foreach (iDB2Parameter param in cmd.Parameters)
                            {
                                strValue += param.ParameterName + " = " + (param.Value ?? "Null") + "//";
                            }

                            //Logger.WriteTrace(false, strValue);
                        }
                        else
                        {
                            if (cmd is string)
                            {
                                //Logger.WriteTrace(false, cmd.ToString());
                            }
                        }
                    }
                }

            }
            catch (iDB2Exception ex)
            {
                CloseConnection();
                lastError = ex.Message.ToString().Trim();
            }
            CloseConnection();
            return listResult;

        }

        public int GetMyReaderFieldCount()
        {
            int fieldCount = myReader.FieldCount;
            return fieldCount;
        }
    }
}
