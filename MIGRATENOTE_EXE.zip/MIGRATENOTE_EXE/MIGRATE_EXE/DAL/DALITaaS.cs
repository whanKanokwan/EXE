﻿using IBM.Data.DB2.iSeries;
using MIGRATE_EXE.APIProvider.Models;
using MIGRATE_EXE.log;
using MIGRATE_EXE.Models;
using MIGRATE_EXE.Utility;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.DALService
{
    internal class DALITaaS
    {
        public string lastError;
        private static string fromSystem;
        private static string toSystem;
        private static string dbType;
        private static string dbTypeToSystem;
        private int commitRecord;
        private string useMultiTask;
        private static List<Task> tasks = new List<Task>();
        private static int toSystemTimeout = 0;
        private static int mutiTaskQueueLength = 0;

        private iDB2Connection iDB2Con;
        private IDALClass DAL;
        private IDALClass DALDestination;
        private IDALClass DALNote;

        public DALITaaS()
        {
            IBlockConfig bconf = ConfigFactory.GetConfig();
            commitRecord = bconf.CommitRecord == "" ? 0 : Convert.ToInt32(bconf.CommitRecord);
            useMultiTask = bconf.UseMultiTask;
            mutiTaskQueueLength = Convert.ToInt32(bconf.MultiTaskQueueLength);
            fromSystem = bconf.AS400_SYSTEM;
            toSystem = bconf.NOTE_SYSTEM;
            string _commandTimeout = bconf.CommandTimeout;
            int cmdTimeout = -1;
            if (!string.IsNullOrEmpty(_commandTimeout))
            {
                int.TryParse(_commandTimeout, out cmdTimeout);
            }
            DALBasic basic = new DALBasic();
            dbType = basic.GetDataBase(fromSystem).ToUpper().Trim();
            dbTypeToSystem = basic.GetDataBase(toSystem).ToUpper().Trim();

            DAL = New_DAL(dbType, fromSystem, cmdTimeout);

            _commandTimeout = bconf.CommandTimeout;
            cmdTimeout = -1;
            if (!string.IsNullOrEmpty(_commandTimeout))
            {
                int.TryParse(_commandTimeout, out cmdTimeout);
            }
            toSystemTimeout = cmdTimeout;
            DALDestination = New_DAL(dbTypeToSystem, toSystem, cmdTimeout);
        }

        public DALITaaS(string dbType,string system , int cmdTimeout )
        {
            DALNote = New_DAL(dbType, system, cmdTimeout);
        }

        private static IDALClass New_DAL(string dbType, string system, int cmdTimeout)
        {
            if (dbType == "AS400")
            {
                IDALClass DAL = new DALAS400(system);
                if (cmdTimeout >= 0)
                {
                    DAL.SetCommandTimeout(cmdTimeout);
                }

                return DAL;
            }
            else if (dbType == "SQLSERVER")
            {
                IDALClass DAL = new DALMSSQL(system);
                if (cmdTimeout >= 0)
                {
                    DAL.SetCommandTimeout(cmdTimeout);
                }

                return DAL;
            }

            return null;
        }

        //public bool CheckWaiting()
        //{
        //    IBlockConfig bconf = ConfigFactory.GetConfig();
        //    string sqlCheck = bconf.GetSQLFromList("WAITFOR_SQL");
        //    DataSet DS = new DataSet();

        //    if (sqlCheck.Trim() != "")
        //    {
        //        DS = DAL.ExecuteDataSet(sqlCheck);

        //        if (DS != null && DS.Tables.Count > 0 && DS.Tables[0].Rows.Count <= 0)
        //        {
        //            return false;
        //        }
        //    }
        //    else
        //    {
        //        return false;
        //    }

        //    return true;
        //}

        public bool TransferData3(string strSourceFile, string strDestinationFile, Criteria data, ref string strMsgDes)
        {
            DataSet ds = new DataSet();
            DataSet dsDestination = new DataSet();
            string strSQL = "";
            string strParam = "";
            string strSQLStructure = "";
            bool firstLoop = true;
            int minField = 0;
            // ArrayList
            ArrayList arList = new ArrayList();
            ArrayList arColumn = new ArrayList();

            string strInsert1 = "";
            string strInsert2 = "";

            int numberRec = 0;
            int exeRec = 0;
            int numRows = 0;

            bool success = false;
            try
            {
                strSQL = strSourceFile.Trim();

                //Console.WriteLine(strSQL);
                Program.recordSummary += "\n\t SELECT AS400 ";
                string strTime = " Time : " + DateTime.Now.ToString("HH:mm:ss");
                Console.WriteLine("Select AS400 From Script..");
                Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                ds = DAL.ExecuteDataSet(strSQL, ref strMsgDes);
                Console.WriteLine("Result : " + ds.Tables[0].Rows.Count.ToString("#,###"));
                Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                Console.WriteLine("End AS400 From Script..");

                Program.recordSummary += "\t\t" + ds.Tables[0].Rows.Count.ToString("#,###") + " Records.";
                Program.recordSummary += strTime + " - " + DateTime.Now.ToString("HH:mm:ss");


                if (ds == null)
                {
                    return false;
                }

                strSQLStructure = "SELECT * FROM " + strDestinationFile + " WHERE 1=0";
                dsDestination = DALDestination.ExecuteDataSet(strSQLStructure, ref strMsgDes);
                if(dsDestination == null)
                {
                    return false;
                }

                if (dsDestination.Tables.Count > 0)
                {
                    dsDestination.Tables[0].Columns.Remove("id");
                }

                Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                Console.WriteLine("Prepare Data..");
                DataSet dsClone = ds.Copy();
                foreach(DataColumn col in ds.Tables[0].Columns)
                {
                    foreach (DataColumn column in dsDestination.Tables[0].Columns)
                    {
                        if(col.ColumnName.ToLower() == column.ColumnName.ToLower())
                        {
                            col.ColumnName = column.ColumnName;
                            dsClone.Tables[0].Columns[col.ColumnName].ColumnName = column.ColumnName;

                            if(col.ColumnName.ToLower() == "noteflag")
                            {
                                foreach (System.Data.DataRow dr in dsClone.Tables[0].Rows)
                                {
                                    dr[col.ColumnName] = "P";
                                }
                            }

                            if (col.DataType.Name != column.DataType.Name)
                            {
                                dsClone.Tables[0].Columns.Add(col.ColumnName + "_new", column.DataType);
                                foreach (System.Data.DataRow dr in dsClone.Tables[0].Rows)
                                {  

                                    if(column.DataType.Name.Contains("DateTime"))
                                    {
                                        string firstIssueDate = dr[col.ColumnName].ToString() == "" ? "" : DateTime.ParseExact(dr[col.ColumnName].ToString(), "yyyyMMdd HH:mm:ss", CultureInfo.InvariantCulture).ToString();
                                        if (!string.IsNullOrEmpty(firstIssueDate))
                                        {
                                            dr[col.ColumnName + "_new"] = firstIssueDate;
                                        }
                                    }
                                    else if (column.DataType.Name.Contains("Decimal"))
                                    {
                                        string de = dr[col.ColumnName].ToString() == "" ? "" : Convert.ToDecimal(dr[col.ColumnName].ToString()).ToString();
                                        if (!string.IsNullOrEmpty(de))
                                            dr[col.ColumnName + "_new"] = de;
                                    }
                                    else if (column.DataType.Name.Contains("String"))
                                    {
                                        dr[col.ColumnName + "_new"] = dr[col.ColumnName].ToString();
                                    }
                                  
                                }
                                dsClone.Tables[0].Columns.Remove(col.ColumnName);
                                dsClone.Tables[0].Columns[col.ColumnName + "_new"].ColumnName = col.ColumnName;
                            }
                          
                            break;
                        }
                    }
                }
                Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));

                Program.recordSummary += "\n\t INSERT " + strDestinationFile;
                Program.recordSummary += "\t\t" + dsClone.Tables[0].Rows.Count.ToString("#,###") + " Records.";
                string strTime2 = " Time : " + DateTime.Now.ToString("HH:mm:ss");
                Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                Console.WriteLine("Insert MSSQL..");
                success = DALDestination.BulkCopy(dsClone.Tables[0], strDestinationFile, ref strMsgDes);
                Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                Console.WriteLine("End Insert MSSQL..");
                Program.recordSummary += strTime2 + " - " + DateTime.Now.ToString("HH:mm:ss");
            }
            catch (Exception ex)
            {
                success = false;
                strMsgDes = ex.Message;
            }

            return success;
        }

        public bool TransferData2(string strSourceFile, string strDestinationFile, Criteria data, ref string strMsgDes)
        {
            DataSet ds = new DataSet();
            DataSet dsDestination = new DataSet();
            string strSQL = "";
            string strParam = "";
            string strSQLStructure = "";
            bool firstLoop = true;
            int minField = 0;
            // ArrayList
            ArrayList arList = new ArrayList();
            ArrayList arColumn = new ArrayList();

            string strInsert1 = "";
            string strInsert2 = "";

            int numberRec = 0;
            int exeRec = 0;
            int numRows = 0;

            bool success = false;
            try
            {
                strSQL = strSourceFile.Trim();

                //Console.WriteLine(strSQL);
                Program.recordSummary += "\n\t SELECT AS400 ";
                string strTime = " Time : " + DateTime.Now.ToString("HH:mm:ss");
                Console.WriteLine("Select AS400 From Script..");
                Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                bool status = this.SetDataReader(strSQL,ref numRows);
                Console.WriteLine("Result : " + numRows.ToString("#,###"));
                Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                Console.WriteLine("End AS400 From Script..");

                Program.recordSummary += "\t\t" + numRows.ToString("#,###") + " Records.";
                Program.recordSummary += strTime + " - " + DateTime.Now.ToString("HH:mm:ss");

                // get Structure from Destination Table
                strSQLStructure = "SELECT * FROM " + strDestinationFile + " WHERE 1=0";
                dsDestination = DALDestination.ExecuteDataSet(strSQLStructure, ref strMsgDes);

                if(dsDestination == null)
                {
                    return false;
                }

                // remove id from Destination
                if(dsDestination.Tables.Count > 0)
                {
                    dsDestination.Tables[0].Columns.Remove("id");
                }
                // Loop data from AS400
                Object[] myValues = null;
                Console.WriteLine("Generate Script Insert MSSQL..");
                Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                int index = 1;

                while (this.ReadReader(ref myValues))
                {
                    Console.WriteLine("Generate SQL {0} of {1}", index,numRows);
                    if (firstLoop)
                    {
                        firstLoop = false;
                        minField = this.GetReaderFieldCount();
                        if(dsDestination.Tables[0].Columns.Count < minField)
                        {
                            minField = dsDestination.Tables[0].Columns.Count;
                        }
                        // Create Statement SQL Insert 
                        for(int i = 0;i < minField;i++)
                        {
                            string strColumn = dsDestination.Tables[0].Columns[i].ColumnName.ToString().Trim();
                            arColumn.Add("@" + strColumn.Trim());
                            if (strInsert1.Trim() == "")
                            {
                                strInsert1 += " INSERT INTO " + strDestinationFile.Trim() + " ( " +
                                                    strColumn.Trim();
                                strInsert2 += " VALUES (@" + strColumn.Trim();
                            }
                            else
                            {
                                strInsert1 += ", " + strColumn.Trim();
                                strInsert2 += ", @" + strColumn.Trim();
                            }
                        }

                        if (strInsert1.Trim() != "")
                        {
                            strInsert1 += ") " + strInsert2.Trim() + ")";
                        }
                    }

                    IDbCommand cmd = DALDestination.CreateCommand();
                    IDbDataParameter dp;
                    cmd.CommandText = strInsert1;
                    string strValue = "";
                    for(int i = 0; i < arColumn.Count;i++)
                    {
                        if(i == 0)
                        {
                            strValue += "'" + myValues[i].ToString().Trim() + "'";
                        }
                        else
                        {
                            strValue += ",'" + myValues[i].ToString().Trim() + "'";
                        }

                        dp = cmd.CreateParameter();
                        dp.ParameterName = arColumn[i].ToString().Trim();
                        var colType = myValues[i].GetType().ToString().ToLower();
                        if(colType.Contains("string"))
                        {
                            dp.Value = myValues[i]?.ToString()?.Trim();
                        }
                        else if (colType.Contains("dbnull") || myValues[i].ToString()?.Trim()?.ToLower() == "null")
                        {
                            dp.Value = DBNull.Value;    
                        }
                        else
                        {
                            dp.Value = myValues[i]?.ToString()?.Trim();
                        }

                        cmd.Parameters.Add(dp);
                    }

                    if(cmd != null)
                    {
                        arList.Add(cmd);
                        numberRec++;
                        exeRec++;
                    }

                    if(commitRecord > 0)
                    {
                        if (exeRec >= commitRecord)
                        {
                            if (useMultiTask.Trim() == "Y")
                            {
                                InsertMultiTask(toSystem, arList, mutiTaskQueueLength);
                                success = true;
                            }
                            else
                            {
                                success = DALDestination.ExecuteTransSql(arList, ref strMsgDes);
                            }

                            exeRec = 0;
                            arList.Clear();
                            if (!success)
                            {
                                break;
                            }
                        }
                    }

                    index++;
                }
                Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                Console.WriteLine("End Generate Script Insert MSSQL..");

                if (exeRec > 0)
                {
                    Program.recordSummary += "\n\t INSERT " + strDestinationFile;
                    Program.recordSummary += "\t\t" + arList.Count + " Records.";
                    string strTime2 = " Time : " + DateTime.Now.ToString("HH:mm:ss");
                    Console.WriteLine("Insert MSSQL..");
                    Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                    if (useMultiTask.Trim() == "Y")
                    {
                        InsertMultiTask(toSystem, arList, mutiTaskQueueLength);
                        success = true;
                    }
                    else
                    {
                        success = DALDestination.ExecuteTransSql(arList, ref strMsgDes);
                    }
                    Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                    Console.WriteLine("End Insert MSSQL..");
                    Program.recordSummary += strTime2 + " - " + DateTime.Now.ToString("HH:mm:ss");
                }

                if (useMultiTask.Trim() == "Y")
                {
                    Task.WaitAll(tasks.ToArray());
                    success = CheckTaskCompleted();
                }
            }
            catch (Exception ex)
            {
                success = false;
                strMsgDes = ex.Message;
            }

            return success;
        }

        public bool TransferData(string strSourceFile,string strDestinationFile , Criteria data , ref string strMsgDes )
        {
            DataSet ds = new DataSet();
            string strSQL = "";
            string strParam = "";

            bool success = false;
            try
            {
                strSQL = strSourceFile.Trim();

                //Console.WriteLine(strSQL);
                Program.recordSummary += "\n\t SELECT AS400 ";
                string strTime = " Time : " + DateTime.Now.ToString("HH:mm:ss");
                Console.WriteLine("Select AS400 From Script..");
                Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                ds = DAL.ExecuteDataSet(strSQL, ref strMsgDes);
                Console.WriteLine("Result : " + ds.Tables[0].Rows.Count);
                Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                Console.WriteLine("End AS400 From Script..");

                if (ds == null)
                {
                    return false;
                }

                Program.recordSummary += "\t\t" + ds.Tables[0].Rows.Count + " Records.";
                Program.recordSummary += strTime + " - " + DateTime.Now.ToString("HH:mm:ss");

                int fieldCount = 0;
                fieldCount = ds.Tables[0].Columns.Count;
                string strInsert1 = "";
                string strInsert2 = "";
                ArrayList arList = new ArrayList();
                ArrayList arColumn = new ArrayList();

                Console.WriteLine("Generate Script Insert MSSQL..");
                //Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                int index = 1;
                foreach (DataTable table in ds.Tables)
                {
                    foreach (DataRow row in table.Rows)
                    {
                        Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                        Console.WriteLine("Generate SQL {0} of {1}", index, table.Rows.Count);
                        IDbCommand cmd = DALDestination.CreateCommand();
                        strInsert1 = "";
                        strInsert2 = "";
                        foreach (DataColumn col in table.Columns)
                        {
                            
                            string strColumn = col.ColumnName;
                            if (strInsert1.Trim() == "")
                            {
                                strInsert1 += " INSERT INTO " + strDestinationFile.Trim() + " ( " +
                                                    strColumn.Trim();
                                strInsert2 += " VALUES (@" + strColumn.Trim();
                            }
                            else
                            {
                                strInsert1 += ", " + strColumn.Trim();
                                strInsert2 += ", @" + strColumn.Trim();
                            }

                            IDbDataParameter dp;
                            dp = cmd.CreateParameter();
                            dp.ParameterName = col.ColumnName.ToString();
                            var colType = row[col].GetType().ToString();
                            if (colType.Contains("System.String"))
                            {
                                dp.Value = row[col].ToString().Trim();
                            }
                            else if (colType.Contains("System.DBNull"))
                            {
                                dp.Value = DBNull.Value;
                            }
                            else if (colType.Contains("System.Decimal"))
                            {
                                dp.Value = Convert.ToDecimal(row[col]);
                            }
                            else if (colType.Contains("System.DateTime"))
                            {
                                dp.Value = SqlDbType.DateTime;
                            }
                            else
                            {
                                dp.Value = row[col].ToString().Trim();
                            }

                            // Fix Code
                            if(col.ColumnName == "noteFlag")
                            {
                                dp.Value = "P";
                            }

                            cmd.Parameters.Add(dp);
                        }
                        if (strInsert1.Trim() != "")
                        {
                            strInsert1 += ") " + strInsert2.Trim() + ")";
                        }

                        cmd.CommandText = strInsert1;
                        arList.Add(cmd);

                        Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                        index++;

                        //Console.WriteLine(cmd);
                    }
                }
                //Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                Console.WriteLine("End Generate Script Insert MSSQL..");

                Program.recordSummary += "\n\t INSERT " + strDestinationFile;
                Program.recordSummary += "\t\t" + arList.Count + " Records.";
                string strTime2 = " Time : " + DateTime.Now.ToString("HH:mm:ss");
                Console.WriteLine("Insert MSSQL..");
                Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                success =  DALDestination.ExecuteTransSql(arList, ref strMsgDes);
                Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                Console.WriteLine("End Insert MSSQL..");
                Program.recordSummary += strTime2 + " - " + DateTime.Now.ToString("HH:mm:ss");
            }
            catch (Exception ex)
            {
                success = false;
                strMsgDes = ex.Message;
            }

            return success;
        }

        public bool SetDataReader(string command, ref int numRows)
        {
            return DAL.SetDataReader(command, ref numRows);
        }

        public int GetReaderFieldCount()
        {
            return DAL.GetMyReaderFieldCount();
        }

        public bool ReadReader(ref Object[] myValues)
        {
            return DAL.ReadMyReader(ref myValues);
        }

        private void createLogDetail()
        {
            if(!Program.isCreateLogDetail)
            {
                IBlockConfig bconf = ConfigFactory.GetConfig();
                // Create LogDetailMSSQL 
                string strPath = string.Empty;
                Logger.WriteTrace(false, bconf.LogMSSQLDetailColumn, 0 , bconf.LogMssqlDetailFile , false , ref strPath);
                if(strPath != "")
                {
                    if(!Program.pathDetailMSSQL.Where(p => p == strPath).Any())
                        Program.pathDetailMSSQL.Add(strPath);
                }
                Program.isCreateLogDetail = true;
            }
        }
        
        private void createLogSummary()
        {
            if(!Program.isCreateLogSummary)
            {
                IBlockConfig bconf = ConfigFactory.GetConfig();
                // Create LogDetailMSSQL 
                string strPath = string.Empty;
                Logger.WriteTrace(false, bconf.LogMSSQLSumColumn, 0 , bconf.LogMssqlSumFile , false , ref strPath);
                if(strPath != "")
                {
                    if(!Program.pathSumMSSQL.Where(p=>p == strPath).Any())
                        Program.pathSumMSSQL.Add(strPath);
                }
                Program.isCreateLogSummary = true;
            }
        }

        public bool NoteProcess2(string strDestinationFile, string strParameter, Criteria criteria, string spStoreList, string strUpdateFlag, ref string strMsgDes)
        {
            IBlockConfig bconf = ConfigFactory.GetConfig();
            CultureInfo ci = new CultureInfo("en-US");
            bool status = false;
            bool statusUpdate = false;
            DataSet ds = new DataSet();
            string strSQL = "";
            string strParam = "";
            DataSet dsResult = new DataSet();
            string strExeption = string.Empty;
            List<string> idError = new List<string>();
            int countRow = 0;
            string strUpdate = "";
            string strPath = "";
            bool checkParam = false;
            bool checkStatusExe = false;
            List<LogData> logData = new List<LogData>();
            try
            {
                strParam = strParameter.Replace("@start", criteria.start.ToString())
                                            .Replace("@end", criteria.end.ToString());

                strSQL = "SELECT * FROM " + strDestinationFile + " " + strParam;
                ds = DALNote.ExecuteDataSet(strSQL, ref strMsgDes);
                List<Param> listStore = JsonConvert.DeserializeObject<List<Param>>(spStoreList);
                string paramName = string.Empty;
                List<Result> param = new List<Result>();
                foreach (DataTable tb in ds.Tables)
                {
                    int numRow = 1;
                    countRow = tb.Rows.Count;

                    int round = (int)Math.Ceiling(Convert.ToDouble(tb.Rows.Count) / Convert.ToDouble(bconf.SQLRecord));

                    while (round > 0)
                    {
                        DataRow row = tb.Rows[0];
                        DataRow last = tb.Rows[tb.Rows.Count - 1];

                        if (param.Where(p => p.name == "end" && p.value > 0).Any())
                        {
                            param.FirstOrDefault(p => p.name == "start").value = param.FirstOrDefault(p => p.name == "end").value + 1;
                            param.FirstOrDefault(p => p.name == "start").text = (Convert.ToInt32(param.FirstOrDefault(p => p.name == "end").text) + 1).ToString();
                        }
                        else
                        {
                            param.Add(new Result()
                            {
                                name = "start",
                                text = "1",
                                value = Convert.ToInt32(row["id"]),
                            });
                        }

                        if (param.Where(p => p.name == "end" && p.value > 0).Any())
                        {

                            int end = (param.FirstOrDefault(p => p.name == "start").value + Convert.ToInt32(bconf.SQLRecord)) - 1;

                            if(end > Convert.ToInt32(last["id"]))
                            {
                                param.FirstOrDefault(p => p.name == "end").value = Convert.ToInt32(last["id"]);
                            }
                            else
                            {
                                param.FirstOrDefault(p => p.name == "end").value = end;
                            }

                            int endT = (Convert.ToInt32(param.FirstOrDefault(p => p.name == "start").text) + Convert.ToInt32(bconf.SQLRecord) - 1);
                            if(endT > countRow)
                            {
                                param.FirstOrDefault(p => p.name == "end").text = countRow.ToString();
                            }
                            else
                            {
                                param.FirstOrDefault(p => p.name == "end").text = endT.ToString();
                            }
                            
                        }
                        else
                        {
                            if(countRow < Convert.ToInt32(bconf.SQLRecord))
                            {
                                param.Add(new Result()
                                {
                                    name = "end",
                                    text = countRow.ToString(),
                                    value = (Convert.ToInt32(row["id"]) + Convert.ToInt32(bconf.SQLRecord)) - 1,
                                });
                            }
                            else
                            {
                                param.Add(new Result()
                                {
                                    name = "end",
                                    text = bconf.SQLRecord,
                                    value = (Convert.ToInt32(row["id"]) + Convert.ToInt32(bconf.SQLRecord)) - 1,
                                });
                            }

                          
                        }

                        Console.WriteLine(string.Format("Select row : {0}-{1} of {2} rows (id {3}-{4})", param.FirstOrDefault(p => p.name == "start").text, param.FirstOrDefault(p => p.name == "end").text, tb.Rows.Count, param.FirstOrDefault(p => p.name == "start").value, param.FirstOrDefault(p => p.name == "end").value));
                        SqlCommand cmd = new SqlCommand();
                        SqlParameterCollection sp = cmd.Parameters;
                        List<SqlParameter> sqlParameters = new List<SqlParameter>();
                        checkStatusExe = true;
                        foreach (Param store in listStore)
                        {
                            sp.Clear();

                            var listParam = store.value.ToString().Split(',');
                            for (int i = 0; i < listParam.Count(); i++)
                            {
                                paramName = listParam[i].Replace("@", "");

                                sp.Add(new SqlParameter("@" + paramName, SqlDbType.Int)).Value = param[i].value;
                            }

                            Console.WriteLine(string.Format("==> Exe Store : {0} Start : {1}", store.name, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));

                            var logEXEC = new LogData();
                            logEXEC.text = "EXEC " + store.name;
                            logEXEC.startTime = DateTime.Now.ToString("HH:mm:ss");
                            dsResult = DALNote.ExecuteStoreProcedure(store.name, (object)sp, ref strExeption);
                            logEXEC.endTime = DateTime.Now.ToString("HH:mm:ss");

                            logData.Add(logEXEC);

                            if (dsResult.Tables.Count == 0)
                            {
                                checkStatusExe = false;
                                Console.WriteLine(string.Format("==> Error Exe Store : {0} End : {1}", store.name, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                                createLogDetail();
                                Logger.WriteTrace(false, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", ci), 0, bconf.LogMssqlDetailFile, true, ref strPath);
                                Logger.WriteTrace(false, "Execute Store :" + store.name, 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, "Error", 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, row["id"].ToString(), 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, strExeption, 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                break;
                            }
                            else if (dsResult.Tables[0].Rows.Count > 0)
                            {
                                foreach (DataRow dr in dsResult.Tables[0].Rows)
                                {
                                    if (dr["pStatus"].ToString() == "0")
                                    {
                                        checkStatusExe = false;
                                        Console.WriteLine(string.Format("==> Error Exe Store : {0} End : {1}", store.name, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                                        createLogDetail();
                                        Logger.WriteTrace(false, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", ci), 0, bconf.LogMssqlDetailFile, true, ref strPath);
                                        Logger.WriteTrace(false, "Execute Store :" + store.name, 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                        Logger.WriteTrace(false, "Error", 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                        Logger.WriteTrace(false, dr["pId"].ToString(), 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                        Logger.WriteTrace(false, strExeption, 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine(string.Format("==> Complete Exe Store : {0} End : {1}", store.name, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                            }
                        }

                        numRow++;
                        round--;
                    }
                   
                }

                if (logData.Count > 0)
                {
                    var groupByText = logData.GroupBy(p => p.text).Distinct();
                    if (groupByText.Count() > 0)
                    {
                        foreach (var group in groupByText)
                        {
                            Program.recordSummary += "\n\t" + group.Key + "\t\t" + logData.Count(p => p.text == group.Key) + " Records. Time : " + logData.Where(p => p.text == group.Key).First().startTime + " - " + logData.Where(p => p.text == group.Key).Last().endTime;
                        }
                    }
                }

                if (idError.Count() > 0)
                {
                    createLogSummary();
                    Logger.WriteTrace(false, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", ci), 0, bconf.LogMssqlSumFile, true, ref strPath);
                    Logger.WriteTrace(false, "DashBoard", 0, bconf.LogMssqlSumFile, false, ref strPath);
                    Logger.WriteTrace(false, "Error", 0, bconf.LogMssqlSumFile, false, ref strPath);
                    Logger.WriteTrace(false, idError.Distinct().Count().ToString(), 0, bconf.LogMssqlSumFile, false, ref strPath);
                    Logger.WriteTrace(false, countRow.ToString(), 0, bconf.LogMssqlSumFile, false, ref strPath);

                    status = false;
                }
                else
                {
                    status = true;
                }
            }
            catch (Exception ex)
            {
                strMsgDes = ex.Message;
            }

            return status;
        }

        public bool NoteProcess(string strDestinationFile,string strParameter, Criteria criteria, string spStoreList ,string strUpdateFlag, ref string strMsgDes)
        {
            IBlockConfig bconf = ConfigFactory.GetConfig();
            CultureInfo ci = new CultureInfo("en-US");
            bool status = false;
            bool statusUpdate = false;
            DataSet ds = new DataSet();
            string strSQL = "";
            string strParam = "";
            DataSet dsResult = new DataSet();
            string strExeption = string.Empty;
            List<string> idError = new List<string>();
            int countRow = 0;
            string strUpdate = "";
            string strPath = "";
            bool checkParam = false;
            bool checkStatusExe = false;
            List<LogData> logData = new List<LogData>();
            try
            {
                strParam = strParameter.Replace("@start", criteria.start.ToString())
                                            .Replace("@end", criteria.end.ToString());

                strSQL = "SELECT * FROM " + strDestinationFile + " " + strParam;
                ds = DALNote.ExecuteDataSet(strSQL, ref strMsgDes);
                List<Param> listStore = JsonConvert.DeserializeObject<List<Param>>(spStoreList);
                string paramName = string.Empty;
                foreach (DataTable tb in ds.Tables)
                {
                    int numRow = 1;
                    countRow = tb.Rows.Count;
                    foreach (DataRow row in tb.Rows)
                    {
                        Console.WriteLine(string.Format("Select row : {0} of {1} rows", numRow, tb.Rows.Count));
                        SqlCommand cmd = new SqlCommand();
                        SqlParameterCollection sp = cmd.Parameters ;
                        List<SqlParameter> sqlParameters = new List<SqlParameter>();
                        checkStatusExe = true;
                        foreach (Param store in listStore)
                        {
                            sp.Clear();
                            var listParam = store.value.ToString().Split(',');
                            for (int i = 0; i < listParam.Count(); i++)
                            {
                                checkParam = false;
                                paramName = listParam[i].Replace("@", "");
                                foreach (DataColumn col in tb.Columns)
                                {
                                    if (paramName.ToLower() == col.ColumnName.ToLower())
                                    {
                                        string colType = col.DataType.FullName.ToString();
                                        SqlDbType sqlDb = SqlDbType.VarChar;
                                        if (colType.Contains("System.DBNull"))
                                        {
                                            sqlDb = SqlDbType.VarChar;
                                        }
                                        else if (colType.Contains("System.Decimal"))
                                        {
                                            sqlDb = SqlDbType.Decimal;
                                        }
                                        else if (colType.Contains("System.DateTime"))
                                        {
                                            sqlDb = SqlDbType.DateTime;
                                        }
                                        checkParam = true;
                                        if (sqlDb == SqlDbType.Decimal)
                                        {
                                            sp.Add(new SqlParameter("@" + paramName, sqlDb)).Value = row[col].ToString() == "" ? 0 : Convert.ToDecimal(row[col]);
                                        }
                                        else if (sqlDb == SqlDbType.DateTime)
                                        {
                                            sp.Add(new SqlParameter("@" + paramName, sqlDb)).Value = row[col].ToString() == "" ? DBNull.Value : row[col];
                                        }
                                        else
                                        {
                                            sp.Add(new SqlParameter("@" + paramName, sqlDb)).Value = row[col];
                                        }
                                    
                                        break;
                                    }
                                }

                                if(checkParam == false)
                                {
                                    sp.Add(new SqlParameter("@" + paramName, SqlDbType.VarChar)).Value = "";
                                }
                            }

                            Console.WriteLine(string.Format("==> Exe Store : {0} Start : {1}", store.name, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));

                            var logEXEC = new LogData();
                            logEXEC.text = "EXEC " + store.name;
                            logEXEC.startTime = DateTime.Now.ToString("HH:mm:ss");
                            dsResult = DALNote.ExecuteStoreProcedure(store.name, (object)sp, ref strExeption);
                            logEXEC.endTime = DateTime.Now.ToString("HH:mm:ss");
                           
                            logData.Add(logEXEC);

                            if(dsResult.Tables.Count == 0)
                            {
                                checkStatusExe = false;
                                Console.WriteLine(string.Format("==> Error Exe Store : {0} End : {1}", store.name, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                                createLogDetail();
                                Logger.WriteTrace(false, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", ci), 0, bconf.LogMssqlDetailFile, true, ref strPath);
                                Logger.WriteTrace(false, "Execute Store :" + store.name, 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, "Error", 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, row["id"].ToString(), 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, strExeption, 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                break;
                            }
                            else if(dsResult.Tables[0].Rows.Count > 0)
                            {
                                foreach(DataRow dr in dsResult.Tables[0].Rows)
                                {
                                    if(dr["pStatus"].ToString() == "0")
                                    {
                                        checkStatusExe = false;
                                        Console.WriteLine(string.Format("==> Error Exe Store : {0} End : {1}", store.name, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                                        createLogDetail();
                                        Logger.WriteTrace(false, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", ci), 0, bconf.LogMssqlDetailFile, true, ref strPath);
                                        Logger.WriteTrace(false, "Execute Store :" + store.name, 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                        Logger.WriteTrace(false, "Error", 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                        Logger.WriteTrace(false, row["id"].ToString(), 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                        Logger.WriteTrace(false, strExeption, 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine(string.Format("==> Complete Exe Store : {0} End : {1}", store.name, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                            }
                        }

                        // ถ้า EXE Commit
                        if(checkStatusExe)
                        {
                            var logUpdate = new LogData();
                            logUpdate.text = "Update NoteFlag I";
                            
                            strUpdate = strUpdateFlag.Replace("@id", row["id"].ToString()).Replace("@status", "'I'");
                            Console.WriteLine(string.Format("==> Update NoteFlag Start : {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                            logUpdate.startTime = DateTime.Now.ToString("HH:mm:ss");
                            statusUpdate = DALNote.ExecuteSql(strUpdate, ref strExeption);
                            logUpdate.endTime = DateTime.Now.ToString("HH:mm:ss");
                            if (statusUpdate == false)
                            {
                                // Error
                                Console.WriteLine(string.Format("==> Error Update NoteFlag End : {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                                createLogDetail();
                                Logger.WriteTrace(false, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", ci), 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, "Update Process Flags", 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, "Error", 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, row["id"].ToString(), 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, strExeption, 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                idError.Add(row["id"].ToString());
                            }
                            else
                            {
                                Console.WriteLine(string.Format("==> Complete Update NoteFlag End : {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                            }
                        }
                        else
                        {
                            var logUpdate = new LogData();
                            logUpdate.text = "Update NoteFlag E";
                            // Error

                            idError.Add(row["id"].ToString());

                            strUpdate = strUpdateFlag.Replace("@id", row["id"].ToString()).Replace("@status", "'E'");
                            Console.WriteLine(string.Format("==> Update NoteFlag : E Start : {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                            logUpdate.startTime = DateTime.Now.ToString("HH:mm:ss");
                            statusUpdate = DALNote.ExecuteSql(strUpdate, ref strExeption);
                            logUpdate.endTime = DateTime.Now.ToString("HH:mm:ss");
                            if (statusUpdate == false)
                            {
                                // Error
                                createLogDetail();
                                Console.WriteLine(string.Format("==> Error Update NoteFlag End : {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                                Logger.WriteTrace(false, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", ci), 0, bconf.LogMssqlDetailFile, true, ref strPath);
                                Logger.WriteTrace(false, "Update Process Flags", 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, "Error", 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, row["id"].ToString(), 0, bconf.LogMssqlDetailFile, false, ref strPath);
                                Logger.WriteTrace(false, strExeption, 0, bconf.LogMssqlDetailFile, false, ref strPath);
                            }
                            else
                            {
                                Console.WriteLine(string.Format("==> Complete Update NoteFlag End : {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
                            }
                        }
                        numRow++;
                    }
                }

                if(logData.Count > 0)
                {
                    var groupByText = logData.GroupBy(p => p.text).Distinct();
                    if(groupByText.Count() > 0)
                    {
                        foreach(var group in groupByText)
                        {
                            Program.recordSummary += "\n\t" + group.Key + "\t\t" + logData.Count(p => p.text == group.Key) + " Records. Time : " + logData.Where(p => p.text == group.Key).First().startTime + " - " + logData.Where(p => p.text == group.Key).Last().endTime;
                        }
                    }
                }

                if (idError.Count() > 0)
                {
                    createLogSummary();
                    Logger.WriteTrace(false, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", ci), 0, bconf.LogMssqlSumFile, true, ref strPath);
                    Logger.WriteTrace(false, "DashBoard", 0 ,  bconf.LogMssqlSumFile , false, ref strPath);
                    Logger.WriteTrace(false, "Error", 0 ,   bconf.LogMssqlSumFile , false , ref strPath);
                    Logger.WriteTrace(false, idError.Distinct().Count().ToString() , 0 ,  bconf.LogMssqlSumFile , false ,ref strPath);
                    Logger.WriteTrace(false, countRow.ToString() , 0,  bconf.LogMssqlSumFile , false , ref strPath);

                    status = false;
                }
                else
                {
                    status = true;
                }
            }
            catch(Exception ex)
            {
                strMsgDes = ex.Message;
            }

            return status;
        }

        public bool ClearData(string strDelete,Criteria criteria ,ref string strException)
        {
            bool status = false;

            try
            {
                List<Param> listSql = JsonConvert.DeserializeObject<List<Param>>(strDelete);

                ArrayList arrList = new ArrayList();
                string strSql = "";
                foreach(var sql in listSql)
                {
                    strSql = sql.value.Replace("@start", "'" + criteria.start + "'").Replace("@end", "'" + criteria.end + "'");

                    arrList.Add(strSql);
                }

                if(arrList.Count > 0)
                {
                    status =  DALNote.ExecuteTransSql(arrList , ref strException);
                }

            }
            catch(Exception ex)
            {
                status = false;
            }


            return status;
        }

        public List<Result> SelectData(string strSelect , Criteria criteria)
        {
            List<Result> rs = new List<Result>();
            try
            {
                List<Param> listSql = JsonConvert.DeserializeObject<List<Param>>(strSelect);

                string strSql = "";
                foreach (var sql in listSql)
                {
                    strSql = sql.value.Replace("@start", "'" + criteria.start + "'").Replace("@end", "'" + criteria.end + "'");

                    sql.value = strSql;
                }

                if (listSql.Count > 0)
                {
                    rs = DALNote.ExecuteScalarTransSql(listSql);
                }
                else
                {
                    // Error
                }

            }
            catch (Exception ex)
            {
              
            }

            return rs;
        }

        public DataSet SelectAS400ToDataSet(string strSourceFile, Criteria data, ref string strMsgDes)
        {
            string strSQL = string.Empty;
            DataSet ds = new DataSet();
            try
            {
                strSQL = strSourceFile.Trim();

                //Console.WriteLine(strSQL);
                Program.recordSummary += "\n\t SELECT count group by AS400";
                string strTime = " Time : " + DateTime.Now.ToString("HH:mm:ss");
                ds = DAL.ExecuteDataSet(strSQL, ref strMsgDes);
                Program.recordSummary += "\t\t" + ds.Tables[0].Rows.Count + " Records.";
                Program.recordSummary += strTime + " - " + DateTime.Now.ToString("HH:mm:ss");

                return ds;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public DataSet SelectAS400ToDataSetWhereCondition(string strSourceFile, Criteria data, ref string strMsgDes)
        {
            string strSQL = string.Empty;
            DataSet ds = new DataSet();
            try
            {
                strSQL = strSourceFile.Trim().Replace("@start", data.start.ToString())
                                           .Replace("@end", data.end.ToString());

                //Console.WriteLine(strSQL);
                Program.recordSummary += "\n\t SELECT count group by AS400";
                string strTime = " Time : " + DateTime.Now.ToString("HH:mm:ss");
                ds = DAL.ExecuteDataSet(strSQL, ref strMsgDes);
                Program.recordSummary += "\t\t" + ds.Tables[0].Rows.Count + " Records.";
                Program.recordSummary += strTime + " - " + DateTime.Now.ToString("HH:mm:ss");

                return ds;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public DataSet SelectMSSQLToDataSet(string strSourceFile , Criteria criteria, ref string strMsgDes)
        {
            string strSQL = string.Empty;
            DataSet ds = new DataSet();
            try
            {
                strSQL = strSourceFile.Trim().Replace("@start", criteria.start.ToString())
                                            .Replace("@end", criteria.end.ToString())
                                            .Replace("\\'","'");

                Program.recordSummary += "\n\t SELECT count group by MSSQL";
                string strTime = " Time : " + DateTime.Now.ToString("HH:mm:ss");
                ds = DALDestination.ExecuteDataSet(strSQL, ref strMsgDes);
                Program.recordSummary += "\t\t" + ds.Tables[0].Rows.Count + " Records.";
                Program.recordSummary += strTime + " - " + DateTime.Now.ToString("HH:mm:ss");

                return ds;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        private static void InsertMultiTask(string toSystem, ArrayList arList, Int32 runTaskNum)
        {
            string error = "";
            string strMsg = "";
            try
            {
                ArrayList list = (ArrayList)arList.Clone();
                bool status = false;
                ControlTask(runTaskNum);
                //Task n = Task.Factory.StartNew(() =>
                //{
                    DALBasic basic = new DALBasic();
                    string dbType = basic.GetDataBase(toSystem).ToUpper().Trim();
                    IDALClass DALTask = New_DAL(dbType, toSystem, toSystemTimeout);

                    status = DALTask.ExecuteTransSql(arList, ref strMsg);
                //});
                //tasks.Add(n);
            }
            catch(Exception ex)
            {
                error = "Error Muti Task >> " + ex.Message.ToString().Trim() + strMsg;
                Console.WriteLine(error.Trim());
            }
        }

        private static void ControlTask(int numTaskRun)
        {
            string error = "";
            try
            {
                while (TaskRun() >= numTaskRun)
                {
                    Task.WaitAny(tasks.ToArray());
                }
            }
            catch (Exception ex)
            {
                error = "Error control Task >> " + ex.Message.ToString().Trim();
                Console.WriteLine(error.Trim());
            }
        }

        private static int TaskRun()
        {
            int r = 0;
            string error = "";
            try
            {
                foreach(Task t in tasks)
                {
                    if (t.Status != TaskStatus.RanToCompletion)
                        r++;
                }
            }
            catch(Exception ex)
            {
                error = "Error check Task Completed >> " + ex.Message.ToString();
                Console.WriteLine(error.Trim());
            }
            return r;
        }

        private static bool CheckTaskCompleted()
        {
            bool rRes = true;
            string err = "";
            try
            {
                foreach (Task t in tasks)
                {
                    if (t.Status != TaskStatus.RanToCompletion)
                    {
                        rRes = false;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                err = "Error check Task completed >> " + ex.Message.ToString();
                Console.WriteLine(err.Trim());
            }
            return rRes;
        }

        public bool TransferDataSpecialNote(string strSourceFile, string strDestinationFile, Criteria data, ref string strMsgDes)
        {
            DataSet ds = new DataSet();
            DataSet dsDestination = new DataSet();
            DataSet dsResult = new DataSet();
            string strSQL = "";
            string strParam = "";
            string strSQLStructure = "";
            bool firstLoop = true;
            int minField = 0;
            // ArrayList
            ArrayList arList = new ArrayList();
            ArrayList arColumn = new ArrayList();

            string strInsert1 = "";
            string strInsert2 = "";

            int numberRec = 0;
            int exeRec = 0;
            int numRows = 0;

            bool success = false;
            try
            {

                strSQLStructure = "SELECT * FROM " + strDestinationFile + " WHERE 1=0";
                dsDestination = DALDestination.ExecuteDataSet(strSQLStructure, ref strMsgDes);
                if (dsDestination == null)
                {
                    return false;
                }

                if (dsDestination.Tables.Count > 0)
                {
                    dsDestination.Tables[0].Columns.Remove("id");
                }

                strSQL = strSourceFile.Trim();

                List<Param> listSQL = JsonConvert.DeserializeObject<List<Param>>(strSourceFile);

                foreach (Param store in listSQL)
                {
                   
                        Program.recordSummary += "\n\t SELECT AS400 Query : " + store.name;
                        string strTime = " Time : " + DateTime.Now.ToString("HH:mm:ss");
                        Console.WriteLine("Select AS400 From Script : " + store.name);
                        Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                        //strSQL = "SELECT * FROM ( " + store.value + " ) as t where t.noteDate between " + "'" + data.start.ToString() + "'" + " and " + "'" + data.end.ToString() + "'";
                        ds = DAL.ExecuteDataSet(store.value, ref strMsgDes);
                        Console.WriteLine("Result : " + ds.Tables[0].Rows.Count.ToString("#,###"));
                        Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                        Console.WriteLine("End AS400 From Script..");

                        Program.recordSummary += "\t\t" + ds.Tables[0].Rows.Count.ToString("#,###") + " Records.";
                        Program.recordSummary += strTime + " - " + DateTime.Now.ToString("HH:mm:ss");

                        bool haveColumn = false;
                        if (ds != null)
                        {
                            Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                            Console.WriteLine("Prepare Data..");
                            DataSet dsClone = ds.Copy();
                            foreach (DataColumn col in ds.Tables[0].Columns)
                            {
                                haveColumn = false;
                                foreach (DataColumn column in dsDestination.Tables[0].Columns)
                                {
                                   
                                    if (col.ColumnName.ToLower() == column.ColumnName.ToLower())
                                    {
                                        haveColumn = true;

                                        col.ColumnName = column.ColumnName;
                                        dsClone.Tables[0].Columns[col.ColumnName].ColumnName = column.ColumnName;

                                        if (col.ColumnName.ToLower() == "noteflag")
                                        {
                                            foreach (System.Data.DataRow dr in dsClone.Tables[0].Rows)
                                            {
                                                dr[col.ColumnName] = "P";
                                            }
                                        }

                                        if (col.DataType.Name != column.DataType.Name)
                                        {
                                            dsClone.Tables[0].Columns.Add(col.ColumnName + "_new", column.DataType);
                                            foreach (System.Data.DataRow dr in dsClone.Tables[0].Rows)
                                            {

                                                if (column.DataType.Name.Contains("DateTime"))
                                                {
                                                    string firstIssueDate = dr[col.ColumnName].ToString() == "" ? "" : DateTime.ParseExact(dr[col.ColumnName].ToString(), "yyyyMMdd HH:mm:ss", CultureInfo.InvariantCulture).ToString();
                                                    if (!string.IsNullOrEmpty(firstIssueDate))
                                                    {
                                                        dr[col.ColumnName + "_new"] = firstIssueDate;
                                                    }
                                                }
                                                else if (column.DataType.Name.Contains("Decimal"))
                                                {
                                                    string de = dr[col.ColumnName].ToString() == "" ? "" : Convert.ToDecimal(dr[col.ColumnName].ToString()).ToString();
                                                    if (!string.IsNullOrEmpty(de))
                                                        dr[col.ColumnName + "_new"] = de;
                                                }
                                                else if (column.DataType.Name.Contains("String"))
                                                {
                                                    dr[col.ColumnName + "_new"] = dr[col.ColumnName].ToString();
                                                }
                                            }
                                            dsClone.Tables[0].Columns.Remove(col.ColumnName);
                                            dsClone.Tables[0].Columns[col.ColumnName + "_new"].ColumnName = col.ColumnName;
                                        }

                                        break;
                                    }
                                }

                                if (haveColumn == false)
                                {
                                    dsClone.Tables[0].Columns.Remove(col.ColumnName);
                                }
                            }
                            Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                            Program.recordSummary += "\n\t INSERT " + strDestinationFile;
                            Program.recordSummary += "\t\t" + dsClone.Tables[0].Rows.Count.ToString("#,###") + " Records.";
                            string strTime2 = " Time : " + DateTime.Now.ToString("HH:mm:ss");
                            Console.WriteLine("Start Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                            Console.WriteLine("Insert MSSQL.." + " : " + store.name);
                            success = DALDestination.BulkCopy(dsClone.Tables[0], strDestinationFile, ref strMsgDes);
                            Console.WriteLine("End Time {0}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                            Console.WriteLine("End Insert MSSQL..");
                            Program.recordSummary += strTime2 + " - " + DateTime.Now.ToString("HH:mm:ss");
                 
                    }
                }
            }
            catch (Exception ex)
            {
                success = false;
                strMsgDes = ex.Message;
            }

            return success;
        }

    }
}
