﻿using MIGRATE_EXE.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGRATE_EXE.DALService
{
    public interface IDALClass
    {
        bool SetCommandTimeout(int i_CommandTimeout);

        bool OpenConnection();

        bool CloseConnection();

        DataSet ExecuteDataSet(string iDB2Command, ref string strMsgDes);

        bool ExecuteDataSetOfSet(string iDB2Command, ref DataSet ds, ref string strMsgDes);

        bool CallProcedure(string procedureName, string param1, string param2, ref string strMsg);

        bool SetDataReader(string command, ref int numRows);

        bool ExecuteTransSql(ArrayList arSQL, ref string strException );

        bool ExecuteTransSqlLot(ArrayList arSQL, Int32 records);

        bool BulkCopy(DataTable dt, string tableName , ref string strExeption);

        IDbCommand CreateCommand();

        bool ReadMyReader(ref Object[] myReader);

        DataSet ExecuteStoreProcedure(string spName, object parameters , ref string strException);

        bool ExecuteStoreProcedureLot(List<StoreProcedureList> lists, ref string strException);

        bool ExecuteSql(object obj , ref string strException);

        List<Result> ExecuteScalarTransSql(List<Param> param);

        int GetMyReaderFieldCount();
    }
}
