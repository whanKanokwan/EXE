﻿using System.Configuration;

namespace MIGRATE_EXE.Commons
{
    class AppConfig
    {
        public static string AS400AssignLib
        {
            get { return ConfigurationSettings.AppSettings["AS400AssignLib"]; }
        }

        public static string MongoDb
        {
            get { return ConfigurationSettings.AppSettings["MongoDb"] ; }
        }

        public static string MongoDbName
        {
            get { return ConfigurationSettings.AppSettings["MongoDbName"]; }
        }
    }
}
